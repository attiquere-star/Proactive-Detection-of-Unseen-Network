| Model configuration | Accuracy (%) | Precision (%) | Recall (%) | F1-Score (%) |
|---|---|---|---|---|
| Hybrid | 98.86 ± 0.15 | 97.28 ± 0.32 | 99.94 ± 0.10 | 98.59 ± 0.18 |
| Hybrid-noDomainMask | 98.81 ± 0.19 | 97.19 ± 0.46 | 99.92 ± 0.09 | 98.54 ± 0.24 |
| Hybrid-noEdgeGating | 98.69 ± 0.22 | 96.86 ± 0.52 | 99.97 ± 0.05 | 98.39 ± 0.26 |
| Hybrid-concatFusion | 98.86 ± 0.14 | 97.32 ± 0.33 | 99.90 ± 0.09 | 98.59 ± 0.17 |
