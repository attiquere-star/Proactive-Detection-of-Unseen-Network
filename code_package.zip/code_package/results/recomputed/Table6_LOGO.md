| Held-out family | Model | Detection rate (recall) | FNR |
|---|---|---|---|
| Backdoors | GraphAEGIS | 100.0% | 0.0% |
| Backdoors | Hybrid | 100.0% | 0.0% |
| Worms | GraphAEGIS | 100.0% | 0.0% |
| Worms | Hybrid | 100.0% | 0.0% |
