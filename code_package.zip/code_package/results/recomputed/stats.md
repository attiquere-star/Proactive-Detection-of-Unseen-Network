# Statistics quoted in the manuscript

- UNSW-NB15, Hybrid accuracy: 98.86% ± 0.15 (SD); 95% CI (t, df = 9) [98.75%, 98.96%]
- UNSW-NB15, paired t-test Hybrid vs GraphSAGE (fold-wise accuracy): mean difference 0.04 pp, t(9) = 1.491, p = 0.1702
- UNSW-NB15, accuracy difference Hybrid - BS-GAT: 0.13 pp (no significance test reported in the manuscript)
- NF-UNSW-NB15-v3, Hybrid accuracy: 99.77% ± 0.13 (SD); 95% CI (t, df = 9) [99.68%, 99.86%]
- NF-UNSW-NB15-v3, paired t-test Hybrid vs GraphSAGE (fold-wise accuracy): mean difference 0.07 pp, t(9) = 1.779, p = 0.109
- NF-UNSW-NB15-v3, accuracy difference Hybrid - BS-GAT: 0.07 pp (no significance test reported in the manuscript)
