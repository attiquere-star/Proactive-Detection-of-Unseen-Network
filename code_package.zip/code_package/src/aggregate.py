# -*- coding: utf-8 -*-
"""Step 6. Collects everything that is not produced by recompute_metrics.py: early detection, noise robustness,
gate values, edge-gating statistics, LOGO, learning-curve figures and the confusion-matrix figure."""
import os, sys, json, glob, numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'); OUT = os.path.join(ROOT, 'results'); os.makedirs(OUT, exist_ok=True)
DS = ['UNSW-NB15', 'NF-UNSW-NB15-v3']

def fold_logs(ds):
    """Merge the per-fold json files written by separate runs (different model subsets) of the same fold."""
    res = {}
    for f in sorted(glob.glob(os.path.join(ROOT, 'logs', ds, 'fold*.json'))):
        k = int(os.path.basename(f)[4:].split('_')[0].split('.')[0]); d = json.load(open(f))
        r = res.setdefault(k, {'meta': {}, 'curves': {}}); r['meta'].update(d['meta']); r['curves'].update(d['curves'])
    return res

DISP = {'Hybrid': 'ThreatOrator–GraphAEGIS'}
def mean_sd(v): v = np.array(v, float); return float(v.mean()), float(v.std(ddof=1)) if len(v) > 1 else 0.0

def main():
    summ = {}
    for ds in DS:
        L = fold_logs(ds); s = summ[ds] = {'folds': sorted(L)}
        if not L: continue
        metas = [L[k]['meta'] for k in sorted(L)]
        for key in ('edges_below_tau_train', 'attack_edges_retained_train', 'benign_edges_removed_train'):
            vals = [m[key] for m in metas if key in m]
            if vals: s[key] = mean_sd(vals)
        lv = {}
        for m in metas:
            for l, c in m.get('text_lookup_level_test', {}).items(): lv[l] = lv.get(l, 0) + c
        s['text_lookup_level_test_total'] = lv
        for name in ('Hybrid', 'GraphAEGIS', 'LSTM'):
            e = [m[f'early_{name}'] for m in metas if f'early_{name}' in m]
            if e: s[f'early_{name}'] = {N: mean_sd([x[N] for x in e]) for N in e[0]}
            n = [m[f'noise_{name}'] for m in metas if f'noise_{name}' in m]
            if n: s[f'noise_{name}'] = {kk: mean_sd([x[kk] for x in n]) for kk in ('clean', 'noisy')}
        g = [m['gate_by_family'] for m in metas if 'gate_by_family' in m]
        if g: s['gate_by_family'] = {f: mean_sd([x[f] for x in g if f in x]) for f in g[0]}
        s['seconds_per_fold'] = mean_sd([m.get('seconds', 0) for m in metas])
        # learning curves of fold 1
        c = L[min(L)]['curves']; s['curve_models'] = sorted(c)
        def panel(models, fname, title):
            ms = [m for m in models if m in c]
            if not ms: return
            fig, axes = plt.subplots(len(ms), 2, figsize=(10, 3.2 * len(ms)), squeeze=False)
            for i, m in enumerate(ms):
                ep = [r['epoch'] for r in c[m]]
                for j, (kk, lab) in enumerate((('loss', 'Loss'), ('acc', 'Accuracy'))):
                    ax = axes[i][j]; ax.plot(ep, [r['train_' + kk] for r in c[m]], label='Training', color='#E69F00')
                    ax.plot(ep, [r['val_' + kk] for r in c[m]], label='Validation', color='#56B4E9')
                    ax.set_xlabel('Epoch'); ax.set_ylabel(lab); ax.set_title(f'({"abcd"[2 * i + j]}) {DISP.get(m, m)}: {lab.lower()}'); ax.grid(alpha=.3); ax.legend()
            fig.suptitle(f'{title} ({ds}, fold 1)'); fig.tight_layout(); fig.savefig(os.path.join(OUT, f'{fname}_{ds}.png'), dpi=200); plt.close(fig)
        panel(['LSTM', 'Hybrid'], 'curves_LSTM_Hybrid', 'Training and validation curves')
        panel(['DNN-IDS', 'CNN-IDS'], 'curves_DNN_CNN', 'Training and validation curves')
        panel(['GraphSAGE', 'GAT-IDS'], 'curves_SAGE_GAT', 'Training and validation curves')
        panel(['BS-GAT'], 'curves_BSGAT', 'Training and validation curves')
        # confusion matrices of the hybrid model, summed over the ten test folds
        pf = sorted(glob.glob(os.path.join(ROOT, 'predictions', ds, 'Hybrid', 'fold*.csv')))
        if pf:
            d = pd.concat([pd.read_csv(f) for f in pf]); y, p = d['y_true'].values, d['y_pred'].values
            cm = np.array([[((y == 0) & (p == 0)).sum(), ((y == 0) & (p == 1)).sum()], [((y == 1) & (p == 0)).sum(), ((y == 1) & (p == 1)).sum()]])
            s['hybrid_confusion_sum'] = cm.tolist()
    # early-detection figure (UNSW-NB15)
    e = summ['UNSW-NB15']
    if all(f'early_{n}' in e for n in ('Hybrid', 'GraphAEGIS', 'LSTM')):
        xs = ['5', '10', '20', '50', 'full']
        fig, ax = plt.subplots(figsize=(6.5, 4))
        for n, col in (('Hybrid', '#D55E00'), ('GraphAEGIS', '#0072B2'), ('LSTM', '#009E73')):
            mu = [100 * e[f'early_{n}'][x][0] for x in xs]; sd = [100 * e[f'early_{n}'][x][1] for x in xs]
            ax.errorbar(range(5), mu, yerr=sd, marker='o', capsize=3, label=n, color=col)
        ax.set_xticks(range(5)); ax.set_xticklabels(['5', '10', '20', '50', 'Full flow']); ax.set_xlabel('Packets observed (N)')
        ax.set_ylabel('Accuracy (%)'); ax.grid(alpha=.3); ax.legend(); ax.set_title('Early detection on UNSW-NB15 (mean ± SD, 10 folds)')
        fig.tight_layout(); fig.savefig(os.path.join(OUT, 'Fig10_early_detection.png'), dpi=300); plt.close(fig)
    # confusion-matrix figure
    cms = [(ds, summ[ds].get('hybrid_confusion_sum')) for ds in DS if summ[ds].get('hybrid_confusion_sum')]
    if cms:
        fig, axes = plt.subplots(1, len(cms), figsize=(5 * len(cms), 4.2), squeeze=False)
        for ax, (ds, cm) in zip(axes[0], cms):
            cm = np.array(cm); ax.imshow(cm, cmap='Blues')
            for i in range(2):
                for j in range(2):
                    ax.text(j, i, f'{cm[i, j]:,}\n({100 * cm[i, j] / cm[i].sum():.1f}%)', ha='center', va='center',
                            color='white' if cm[i, j] > cm.max() / 2 else 'black')
            ax.set_xticks([0, 1]); ax.set_xticklabels(['Benign', 'Malicious']); ax.set_yticks([0, 1]); ax.set_yticklabels(['Benign', 'Malicious'])
            ax.set_xlabel('Predicted'); ax.set_ylabel('True'); ax.set_title(f'{ds}: hybrid model, ten test folds')
        fig.tight_layout(); fig.savefig(os.path.join(OUT, 'FigS2_confusion_matrices.png'), dpi=300); plt.close(fig)
    lf = os.path.join(ROOT, 'logs', 'logo.json')
    if os.path.exists(lf): summ['LOGO'] = json.load(open(lf))
    summ['sampling'] = json.load(open(os.path.join(ROOT, 'prepared', 'sampling_info.json')))
    summ['corpus'] = json.load(open(os.path.join(ROOT, 'text', 'corpus_stats.json')))
    for f in glob.glob(os.path.join(ROOT, 'text', 'train_log_*.json')): summ[os.path.basename(f)[:-5]] = json.load(open(f))
    json.dump(summ, open(os.path.join(OUT, 'summary.json'), 'w'), indent=1); print(json.dumps({k: v for k, v in summ.items() if k != 'sampling'}, indent=1)[:6000])

if __name__ == '__main__':
    main()
