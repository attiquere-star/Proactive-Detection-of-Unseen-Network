# -*- coding: utf-8 -*-
"""Writes the row positions of the seeded 50,000-flow subsamples (and their fold numbers) so that the subsamples can be
rebuilt without re-running the sampling. Positions refer to the full dataset as loaded by prepare_data.py
(UNSW-NB15: the four CSV files of the original release concatenated in order 1-4, with repeated header lines removed;
NF-UNSW-NB15-v3: the rows of the released CSV file in their original order). The script checks that the rows selected by
the positions are exactly the rows of prepared/<dataset>.parquet."""
import os, numpy as np, pandas as pd
import prepare_data as P
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(HERE, '..', 'subsample_indices'); os.makedirs(OUT, exist_ok=True)
for name, loader in (('UNSW-NB15', P.load_unsw), ('NF-UNSW-NB15-v3', P.load_nf)):
    df = loader()
    rng = np.random.RandomState(P.SEED); n_total, rare_cap = 50000, 1500
    n_att = int(round(0.4 * n_total)); n_ben = n_total - n_att
    counts = df['family'].value_counts(); fams = [f for f in P.FAMILIES if f in counts.index]
    alloc = {f: int(min(counts[f], rare_cap)) for f in fams}
    rest = n_att - sum(alloc.values()); spare = {f: counts[f] - alloc[f] for f in fams}; tot = sum(spare.values())
    for f in fams: alloc[f] += int(min(spare[f], round(rest * spare[f] / tot)))
    idx = [rng.choice(np.where(df['family'].values == 'Benign')[0], n_ben, replace=False)]
    for f, k in alloc.items(): idx.append(rng.choice(np.where(df['family'].values == f)[0], k, replace=False))
    idx = np.sort(np.concatenate(idx))
    prep = pd.read_parquet(os.path.join(HERE, '..', 'prepared', f'{name}.parquet'))
    sel = df.iloc[idx].reset_index(drop=True)
    assert (sel['src'].values == prep['src'].values).all() and (sel['dst'].values == prep['dst'].values).all()
    assert np.allclose(sel['t'].values, prep['t'].values, equal_nan=True) and (sel['family'].values == prep['family'].values).all()
    pd.DataFrame({'row_position': idx, 'family': prep['family'].values, 'fold': prep['fold'].values}).to_csv(os.path.join(OUT, f'{name}_subsample.csv'), index=False)
    print(name, 'ok', len(idx))
