# -*- coding: utf-8 -*-
"""Step 8. Publication figures (journal style, deep-ocean palette). Every plotted value is read from the saved
re-run outputs: fold-wise metrics (results/recomputed/TableS2_confusion_matrices.csv), saved predictions,
learning-curve logs, results/summary.json and logs/logo.json. Nothing is typed in by hand."""
import os, sys, json, glob, numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import aggregate as AG, recompute_metrics as RM
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
OUT = os.path.join(ROOT, 'results', 'styled'); os.makedirs(OUT, exist_ok=True)
UN, NF = 'UNSW-NB15', 'NF-UNSW-NB15-v3'

# ---------------------------------------------------------------- style
NAVY, TEAL_D, SKY, ICE, MINT, ROSE, CORAL, SLATE, GREY = '#063D59', '#0B5C79', '#A8D8E6', '#D0EBEF', '#63B9A7', '#B96263', '#D88970', '#8FA4B3', '#5B6770'
MODELS = ['DNN-IDS', 'CNN-IDS', 'LSTM', 'GraphSAGE', 'GAT-IDS', 'BS-GAT', 'Hybrid']
COL = {'DNN-IDS': NAVY, 'CNN-IDS': TEAL_D, 'LSTM': SLATE, 'GraphSAGE': MINT, 'GAT-IDS': SKY, 'BS-GAT': CORAL, 'Hybrid': ROSE,
       'GraphAEGIS': TEAL_D, 'ThreatOrator': SKY, 'Hybrid-noDomainMask': MINT, 'Hybrid-noEdgeGating': CORAL, 'Hybrid-concatFusion': SLATE}
LABEL = {'Hybrid': 'Hybrid (proposed)', 'Hybrid-noDomainMask': 'w/o domain\nmask', 'Hybrid-noEdgeGating': 'w/o edge\ngating',
         'Hybrid-concatFusion': 'concat\nfusion', 'ThreatOrator': 'ThreatOrator\n(text only)', 'GraphAEGIS': 'GraphAEGIS\n(graph only)'}
OCEAN = LinearSegmentedColormap.from_list('ocean', ['#FFFFFF', ICE, SKY, '#4C9BB8', TEAL_D, NAVY])
DIVERGE = LinearSegmentedColormap.from_list('div', [NAVY, TEAL_D, SKY, '#F7F7F7', '#E8B8A6', CORAL, ROSE])
plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Liberation Sans', 'DejaVu Sans'], 'font.size': 8,
                     'axes.titlesize': 8.5, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'legend.fontsize': 7,
                     'axes.spines.top': False, 'axes.spines.right': False, 'axes.linewidth': 0.8, 'xtick.major.width': 0.8,
                     'ytick.major.width': 0.8, 'xtick.major.size': 3, 'ytick.major.size': 3, 'legend.frameon': False,
                     'savefig.dpi': 400, 'savefig.bbox': 'tight', 'savefig.pad_inches': 0.04, 'axes.titleweight': 'bold'})

def letter(ax, s, dx=-0.16, dy=1.06):
    ax.text(dx, dy, s, transform=ax.transAxes, fontsize=11, fontweight='bold', va='bottom', ha='left')
def header(ax, s):
    ax.set_title(s, loc='left', fontsize=8.5, fontweight='bold', color=NAVY, pad=6)
def save(fig, name):
    fig.savefig(os.path.join(OUT, name)); plt.close(fig); print('saved', name)

# ---------------------------------------------------------------- data
S1 = pd.read_csv(os.path.join(ROOT, 'results', 'recomputed', 'TableS2_confusion_matrices.csv'))
SUM = json.load(open(os.path.join(ROOT, 'results', 'summary.json')))
LOGO = json.load(open(os.path.join(ROOT, 'logs', 'logo.json')))
def folds(ds, model, k='Accuracy'): return S1[(S1.dataset == ds) & (S1.model == model)].sort_values('fold')[k].values.astype(float)

def ptext(p): return 'P < 0.001' if p < 0.001 else f'P = {p:.3f}' if p < 0.01 else f'P = {p:.2f}'

def bar_dots(ax, ds, models, k='Accuracy', pct=True, ylim=None, rng=None):
    rng = rng or np.random.RandomState(42); sc = 100 if pct else 1
    for i, m in enumerate(models):
        v = folds(ds, m, k) * sc; mu, sd = v.mean(), v.std(ddof=1)
        ax.bar(i, mu, width=0.68, color=COL[m], alpha=0.88 if m != 'Hybrid' else 1, edgecolor='white', linewidth=0.6, zorder=2)
        ax.errorbar(i, mu, yerr=sd, color='#222222', capsize=2.5, lw=0.9, capthick=0.9, zorder=4)
        ax.scatter(i + rng.uniform(-0.17, 0.17, len(v)), v, s=7, facecolor='white', edgecolor=GREY, linewidth=0.6, zorder=5)
    ax.set_xticks(range(len(models))); ax.set_xticklabels([LABEL.get(m, m) for m in models], rotation=0)
    if ylim: ax.set_ylim(*ylim)
    ax.yaxis.grid(True, color='#E6EEF2', lw=0.6, zorder=0); ax.set_axisbelow(True)

def bracket(ax, x1, x2, y, txt, h=0.03):
    ax.plot([x1, x1, x2, x2], [y, y + h, y + h, y], color='#222222', lw=0.8, zorder=6)
    ax.text((x1 + x2) / 2, y + h * 1.3, txt, ha='center', va='bottom', fontsize=6.5, style='italic')

def roc_points(ds, model):
    ys, ps = [], []
    for f in sorted(glob.glob(os.path.join(ROOT, 'predictions', ds, model, 'fold*.csv'))):
        d = pd.read_csv(f); ys.append(d['y_true'].values); ps.append(d['y_prob'].values)
    y, p = np.concatenate(ys), np.concatenate(ps); o = np.argsort(-p); y = y[o]
    tpr = np.r_[0, np.cumsum(y) / y.sum()]; fpr = np.r_[0, np.cumsum(1 - y) / (1 - y).sum()]
    return fpr, tpr

# ---------------------------------------------------------------- Figure: performance overview (main text)
def fig_overview():
    fig = plt.figure(figsize=(7.2, 8.6))
    gs = fig.add_gridspec(3, 6, height_ratios=[1.0, 1.05, 1.0], hspace=0.62, wspace=1.15)
    for j, (ds, lo, hi) in enumerate(((UN, 97.6, 99.75), (NF, 96.5, 100.75))):
        ax = fig.add_subplot(gs[0, 3 * j:3 * j + 3]); bar_dots(ax, ds, MODELS, ylim=(lo, hi))
        ax.set_ylabel('Accuracy (%)'); header(ax, f'{ds}: 10-fold accuracy'); letter(ax, 'ab'[j])
        ax.tick_params(axis='x', labelsize=6.3); plt.setp(ax.get_xticklabels(), rotation=35, ha='right', rotation_mode='anchor')
        a, b = folds(ds, 'Hybrid'), folds(ds, 'GraphSAGE'); t, p, _ = RM.paired_t(list(a), list(b))
        top = max((folds(ds, m) * 100).max() for m in ('GraphSAGE', 'Hybrid'))
        bracket(ax, MODELS.index('GraphSAGE'), MODELS.index('Hybrid'), top + 0.12 * (hi - lo) / 2, ptext(p), h=0.025 * (hi - lo))
    # c: metric heatmap (both datasets)
    ax = fig.add_subplot(gs[1, :4]); mets = [('Accuracy', 'Acc.'), ('Precision', 'Prec.'), ('Recall', 'Rec.'), ('F1', 'F1'), ('AUC', 'AUC'), ('Specificity', '1−FPR')]
    M = np.array([[folds(ds, m, k).mean() * 100 for ds in (UN, NF) for k, _ in mets] for m in MODELS])
    Z = (M - M.mean(0)) / (M.std(0) + 1e-9)
    im = ax.imshow(Z, cmap=DIVERGE.reversed(), aspect='auto', vmin=-2.2, vmax=2.2)
    for i in range(M.shape[0]):
        for jj in range(M.shape[1]):
            ax.text(jj, i, f'{M[i, jj]:.2f}', ha='center', va='center', fontsize=5.6, color='white' if abs(Z[i, jj]) > 1.3 else '#1A1A1A')
    ax.set_yticks(range(len(MODELS))); ax.set_yticklabels([m if m != 'Hybrid' else 'Hybrid (proposed)' for m in MODELS])
    ax.set_xticks(range(M.shape[1])); ax.set_xticklabels([s for _ in (UN, NF) for _, s in mets], fontsize=6.3)
    ax.axvline(len(mets) - 0.5, color='white', lw=3)
    ax.text((len(mets) - 1) / 2, -0.95, UN, ha='center', fontsize=7, fontweight='bold', color=NAVY)
    ax.text(len(mets) + (len(mets) - 1) / 2, -0.95, NF, ha='center', fontsize=7, fontweight='bold', color=NAVY)
    for s in ax.spines.values(): s.set_visible(False)
    ax.tick_params(length=0); letter(ax, 'c', dx=-0.25, dy=1.09)
    # d: ROC zoom (UNSW-NB15)
    ax = fig.add_subplot(gs[1, 4:]); ax.set_position(ax.get_position().translated(0.035, 0))
    for m in MODELS:
        fpr, tpr = roc_points(UN, m)
        ax.plot(fpr * 100, tpr * 100, color=COL[m], lw=1.6 if m == 'Hybrid' else 1.0, label=m if m != 'Hybrid' else 'Hybrid')
    ax.set_xlim(0, 6); ax.set_ylim(90, 100.3); ax.set_xlabel('False positive rate (%)'); ax.set_ylabel('True positive rate (%)')
    header(ax, f'ROC ({UN}, zoom)'); letter(ax, 'd', dx=-0.3)
    ax.legend(loc='lower right', fontsize=5.6, handlelength=1.2, labelspacing=0.25)
    ax.yaxis.grid(True, color='#E6EEF2', lw=0.6); ax.xaxis.grid(True, color='#E6EEF2', lw=0.6)
    # e: ablation (UNSW-NB15)
    ax = fig.add_subplot(gs[2, :4]); abl = ['ThreatOrator', 'GraphAEGIS', 'Hybrid-noDomainMask', 'Hybrid-noEdgeGating', 'Hybrid-concatFusion', 'Hybrid']
    bar_dots(ax, UN, abl, ylim=(70, 101)); ax.set_ylabel('Accuracy (%)'); header(ax, f'Ablation ({UN})'); letter(ax, 'e', dx=-0.12)
    ax.tick_params(axis='x', labelsize=6.3)
    for i, m in enumerate(abl):
        v = folds(UN, m).mean() * 100; ax.text(i, min(v + 1.4, 100.4) if m != 'ThreatOrator' else v + 1.6, f'{v:.2f}', ha='center', fontsize=6, color=NAVY)
    # f: LOGO
    ax = fig.add_subplot(gs[2, 4:]); ax.set_position(ax.get_position().translated(0.035, 0)); fams = ['Worms', 'Backdoors']; w = 0.36
    for j, (m, c) in enumerate((('GraphAEGIS', TEAL_D), ('Hybrid', ROSE))):
        dr = [100 * LOGO[f][m]['detection_rate'] for f in fams]; fp = [100 * LOGO[f][m]['fpr_benign_fold1'] for f in fams]
        xs = np.arange(2) + (j - 0.5) * w
        ax.bar(xs, dr, w * 0.92, color=c, edgecolor='white', label=m if m != 'Hybrid' else 'Hybrid')
        for x, d, f_ in zip(xs, dr, fp):
            ax.text(x, d - 4, f'{d:.0f}%', ha='center', va='top', fontsize=6.5, color='white', fontweight='bold')
            ax.text(x, 4, f'FPR\n{f_:.1f}%', ha='center', va='bottom', fontsize=5.5, color='white')
    ax.set_xticks(range(2)); ax.set_xticklabels([f'{f}\n(n = {LOGO[f]["n_heldout_flows"]})' for f in fams]); ax.set_ylim(0, 118); ax.set_yticks([0, 25, 50, 75, 100])
    ax.set_ylabel('Detection rate (%)'); header(ax, 'Held-out families (LOGO)'); letter(ax, 'f', dx=-0.3)
    ax.legend(loc='upper center', ncol=2, fontsize=6, bbox_to_anchor=(0.5, 1.0), handlelength=1)
    save(fig, 'Fig_performance_overview.png')

# ---------------------------------------------------------------- learning curves
def fig_curves(models, ds, name):
    L = AG.fold_logs(ds); c = L[min(L)]['curves']; ms = [m for m in models if m in c]
    fig, axes = plt.subplots(len(ms), 2, figsize=(7.0, 2.35 * len(ms)), squeeze=False)
    for i, m in enumerate(ms):
        ep = [r['epoch'] for r in c[m]]
        for j, (k, lab) in enumerate((('loss', 'Loss'), ('acc', 'Accuracy'))):
            ax = axes[i][j]; tr = np.array([r['train_' + k] for r in c[m]]); va = np.array([r['val_' + k] for r in c[m]])
            if k == 'acc': tr, va = tr * 100, va * 100
            ax.plot(ep, tr, color=NAVY, lw=1.5, marker='o', ms=2.6, label='Training')
            ax.plot(ep, va, color=CORAL, lw=1.5, marker='s', ms=2.6, label='Validation')
            ax.fill_between(ep, tr, va, color=SKY, alpha=0.25, lw=0)
            ax.set_xlabel('Epoch'); ax.set_ylabel(lab if k == 'loss' else 'Accuracy (%)')
            nm = 'ThreatOrator–GraphAEGIS' if m == 'Hybrid' else m
            header(ax, f'{nm}: {lab.lower()}'); letter(ax, 'abcdef'[2 * i + j], dx=-0.18)
            ax.yaxis.grid(True, color='#E6EEF2', lw=0.6); ax.legend(loc='upper right' if k == 'loss' else 'lower right')
            if k == 'acc':
                lo = min(tr.min(), va.min()); ax.set_ylim(max(lo - 0.02 * (100 - lo) - 0.3, 0), 100.3)
    fig.tight_layout(w_pad=2.5, h_pad=1.6); save(fig, name)

# ---------------------------------------------------------------- early detection
def fig_early():
    e = SUM[UN]; xs = ['5', '10', '20', '50', 'full']
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    for off, (n, c, mk) in zip((-0.12, 0, 0.12), (('Hybrid', ROSE, 'o'), ('GraphAEGIS', TEAL_D, 's'), ('LSTM', SLATE, '^'))):
        mu = np.array([100 * e[f'early_{n}'][x][0] for x in xs]); sd = np.array([100 * e[f'early_{n}'][x][1] for x in xs])
        x = np.arange(5) + off
        ax.errorbar(x, mu, yerr=sd, color=c, marker=mk, ms=5.5, lw=1.6, capsize=2.5, elinewidth=0.9, label='Hybrid (proposed)' if n == 'Hybrid' else n, mec='white', mew=0.7, zorder=3)
    ax.set_xticks(range(5)); ax.set_xticklabels(['5', '10', '20', '50', 'Full flow']); ax.set_xlabel('Packets observed, N')
    ax.set_ylabel('Accuracy (%)'); ax.yaxis.grid(True, color='#E6EEF2', lw=0.6)
    header(ax, f'Early detection on {UN} (mean ± SD, 10 folds)'); ax.legend(loc='lower right', ncol=3, fontsize=6.5)
    lo, hi = ax.get_ylim(); ax.set_ylim(lo - 0.12, hi + 0.04)
    save(fig, 'Fig_early_detection.png')

# ---------------------------------------------------------------- fold accuracies (S7) and confusion matrices (S8)
def fig_folds():
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9))
    for j, (ax, ds) in enumerate(zip(axes, (UN, NF))):
        rng = np.random.RandomState(1)
        data = [folds(ds, m) * 100 for m in MODELS]
        parts = ax.violinplot(data, positions=range(len(MODELS)), widths=0.75, showextrema=False)
        for pc, m in zip(parts['bodies'], MODELS): pc.set_facecolor(COL[m]); pc.set_edgecolor('none'); pc.set_alpha(0.45)
        ax.boxplot(data, positions=range(len(MODELS)), widths=0.18, patch_artist=True, showfliers=False,
                   boxprops=dict(facecolor='white', edgecolor='#333333', lw=0.7), medianprops=dict(color='#333333', lw=0.9),
                   whiskerprops=dict(lw=0.7), capprops=dict(lw=0.7))
        for i, v in enumerate(data): ax.scatter(i + rng.uniform(-0.2, 0.2, len(v)), v, s=6, color=COL[MODELS[i]], edgecolor='white', lw=0.3, zorder=4)
        ax.set_xticks(range(len(MODELS))); ax.set_xticklabels([LABEL.get(m, m) for m in MODELS], fontsize=6)
        ax.set_ylabel('Fold accuracy (%)'); header(ax, ds); letter(ax, 'ab'[j]); ax.yaxis.grid(True, color='#E6EEF2', lw=0.6)
    fig.tight_layout(w_pad=2); save(fig, 'FigS1_fold_accuracy.png')

def fig_cm():
    fig, axes = plt.subplots(1, 2, figsize=(6.4, 2.9))
    for j, (ax, ds) in enumerate(zip(axes, (UN, NF))):
        cm = np.array(SUM[ds]['hybrid_confusion_sum']); pr = cm / cm.sum(1, keepdims=True)
        ax.imshow(pr, cmap=OCEAN, vmin=0, vmax=1)
        for a in range(2):
            for b in range(2):
                ax.text(b, a, f'{cm[a, b]:,}\n{100 * pr[a, b]:.2f}%', ha='center', va='center', fontsize=8, color='white' if pr[a, b] > 0.5 else NAVY, fontweight='bold')
        ax.set_xticks([0, 1]); ax.set_xticklabels(['Benign', 'Malicious']); ax.set_yticks([0, 1]); ax.set_yticklabels(['Benign', 'Malicious'])
        ax.set_xlabel('Predicted class'); ax.set_ylabel('True class'); header(ax, f'{ds} (hybrid, 10 test folds)'); letter(ax, 'ab'[j], dx=-0.32)
        for s in ax.spines.values(): s.set_visible(False)
        ax.tick_params(length=0)
    fig.tight_layout(w_pad=3); save(fig, 'FigS2_confusion_matrices.png')

if __name__ == '__main__':
    fig_overview()
    for ds in (UN, NF):
        fig_curves(['LSTM', 'Hybrid'], ds, f'curves_LSTM_Hybrid_{ds}.png')
        fig_curves(['DNN-IDS', 'CNN-IDS'], ds, f'curves_DNN_CNN_{ds}.png')
        fig_curves(['GraphSAGE', 'GAT-IDS'], ds, f'curves_SAGE_GAT_{ds}.png')
        fig_curves(['BS-GAT'], ds, f'curves_BSGAT_{ds}.png')
    fig_early(); fig_folds(); fig_cm()
