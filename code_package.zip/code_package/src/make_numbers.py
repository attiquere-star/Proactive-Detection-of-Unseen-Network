# -*- coding: utf-8 -*-
"""Step 7. Collects every number quoted in the manuscript into results/numbers.json.
Metrics come from recompute_metrics.py (recomputed from the saved fold-wise predictions);
the remaining values come from results/summary.json written by aggregate.py."""
import os, sys, json, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import recompute_metrics as RM
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')

def main():
    res = RM.load_all(os.path.join(ROOT, 'predictions'))
    out = {'metrics': {}, 'stats': {}}
    for (ds, model), folds in res.items():
        d = out['metrics'].setdefault(ds, {}).setdefault(model, {})
        for k in ('Accuracy', 'Precision', 'Recall', 'F1', 'FPR', 'AUC', 'Specificity'):
            m, sd, ci = RM.summarize(folds, k); d[k] = [m, sd, list(ci)]
        d['fold_acc'] = [f['Accuracy'] for f in folds]
    for ds in RM.DATASETS:
        s = out['stats'].setdefault(ds, {})
        if (ds, 'Hybrid') in res and (ds, 'GraphSAGE') in res:
            t, p, md = RM.paired_t([f['Accuracy'] for f in res[(ds, 'Hybrid')]], [f['Accuracy'] for f in res[(ds, 'GraphSAGE')]])
            s['ttest_vs_GraphSAGE'] = {'t': t, 'p': p, 'mean_diff': md}
    # final points of the fold-1 learning curves and share of flows longer than N packets (early detection)
    import glob, pandas as pd
    import aggregate as AG
    out['curves_final'] = {}
    for ds in RM.DATASETS:
        L = AG.fold_logs(ds)
        if L:
            c = L[min(L)]['curves']
            out['curves_final'][ds] = {mod: v[-1] for mod, v in c.items() if v}
    df = pd.read_parquet(os.path.join(ROOT, 'prepared', 'UNSW-NB15.parquet'))
    P = df['f_Spkts'].values + df['f_Dpkts'].values
    out['share_longer_than'] = {str(n): float((P > n).mean()) for n in (5, 10, 20, 50)}
    out['median_packets'] = float(pd.Series(P).median())
    # source-host type (the node feature of the graph models) versus label, and false positives of the hybrid model
    out['host'] = {}
    for ds in RM.DATASETS:
        d = pd.read_parquet(os.path.join(ROOT, 'prepared', f'{ds}.parquet'))
        ext = ~(d['internal_src'].astype(bool))
        h = {'attack_external_src': float(ext[d['label'] == 1].mean()), 'benign_external_src': float(ext[d['label'] == 0].mean())}
        fp = fpe = 0
        for k in range(1, 11):
            te = d[d['fold'] == k].reset_index(drop=True); pr = pd.read_csv(os.path.join(ROOT, 'predictions', ds, 'Hybrid', f'fold{k}.csv'))
            assert (pr['y_true'].values == te['label'].values).all()
            f = (pr['y_pred'].values == 1) & (pr['y_true'].values == 0); fp += int(f.sum()); fpe += int((f & ext.values[d['fold'].values == k]).sum())
        h['hybrid_fp'] = fp; h['hybrid_fp_external_src'] = fpe
        h['n_attack_src_hosts'] = int(d.loc[d['label'] == 1, 'src'].nunique())
        out['host'][ds] = h
    out['summary'] = json.load(open(os.path.join(ROOT, 'results', 'summary.json')))
    json.dump(out, open(os.path.join(ROOT, 'results', 'numbers.json'), 'w'), indent=1)
    print('numbers.json written')

if __name__ == '__main__':
    main()
