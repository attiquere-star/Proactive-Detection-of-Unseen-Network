# -*- coding: utf-8 -*-
"""Step 3. Feature preprocessing, graph construction and all models (pure PyTorch, no PyG)."""
import numpy as np, pandas as pd, torch, torch.nn as nn, torch.nn.functional as F
from sklearn.ensemble import IsolationForest

TOP_PORTS = [80, 53, 111, 25, 21, 22, 445, 143, 110, 179, 5060, 6881, 1723, 520, 514, 0, 443, 23, 139, 161]
TAU = 0.3

# ------------------------------------------------------------------ features
class Prep:
    """Fitted on the training partition only, then applied unchanged to validation/test partitions."""
    def fit(self, df):
        self.num = [c for c in df.columns if c.startswith('f_')]
        X = self._num(df); self.mu = X.mean(0); self.sd = X.std(0) + 1e-6
        self.cats = {c: df[c].value_counts().index[:10].tolist() for c in df.columns if c.startswith('c_')}
        self.protos = df['proto'].value_counts().index[:8].tolist()
        return self
    def _num(self, df):
        X = df[self.num].values.astype(np.float64)
        X[~np.isfinite(X)] = 0.0  # NF-v3 throughput columns are NaN/inf for zero-duration flows; set to 0
        return np.sign(X) * np.log1p(np.abs(X))
    def transform(self, df):
        parts = [(self._num(df) - self.mu) / self.sd]
        for c, vals in self.cats.items():
            parts.append(np.stack([(df[c].values == v) for v in vals] + [~df[c].isin(vals).values], 1))
        parts.append(np.stack([(df['proto'].values == v) for v in self.protos] + [~df['proto'].isin(self.protos).values], 1))
        parts.append(np.stack([(df['dport'].values == p) for p in TOP_PORTS] + [~df['dport'].isin(TOP_PORTS).values], 1))
        return np.concatenate([p.astype(np.float32) for p in parts], 1)

class EdgeScorer:
    """Isolation Forest fitted on benign training flows; score in [0,1], higher = more anomalous."""
    def fit(self, X, y):
        self.iso = IsolationForest(n_estimators=100, contamination=0.05, random_state=42).fit(X[y == 0])
        s = -self.iso.score_samples(X); self.lo, self.hi = np.percentile(s, 1), np.percentile(s, 99)
        return self
    def score(self, X):
        return np.clip((-self.iso.score_samples(X) - self.lo) / (self.hi - self.lo + 1e-9), 0, 1).astype(np.float32)

# ------------------------------------------------------------------ graph
class Graph:
    """Nodes: (IP address, 60-s window). One edge per flow src->dst; messages are passed in both directions."""
    def __init__(self, df, X, s):
        keys_s = df['src'].values + '|' + df['window'].astype(str).values
        keys_d = df['dst'].values + '|' + df['window'].astype(str).values
        uniq, inv = np.unique(np.concatenate([keys_s, keys_d]), return_inverse=True)
        n = len(df); self.n_nodes = len(uniq)
        self.fsrc = torch.tensor(inv[:n]); self.fdst = torch.tensor(inv[n:])
        internal = np.zeros(self.n_nodes, np.float32)
        internal[inv[:n]] = df['internal_src'].values; internal[inv[n:]] = np.maximum(internal[inv[n:]], df['internal_dst'].values)
        self.x = torch.tensor(np.stack([internal, 1 - internal], 1))
        self.e = torch.tensor(X); self.s = torch.tensor(s)
        # message edges (both directions); each refers to its flow
        self.msrc = torch.cat([self.fsrc, self.fdst]); self.mtgt = torch.cat([self.fdst, self.fsrc])
        self.mflow = torch.cat([torch.arange(n), torch.arange(n)])
        # behaviour vector of each node = mean feature vector of its incident flows (used by BS-GAT)
        beh = torch.zeros(self.n_nodes, X.shape[1]); cnt = torch.zeros(self.n_nodes, 1)
        beh.index_add_(0, self.mtgt, self.e[self.mflow]); cnt.index_add_(0, self.mtgt, torch.ones(len(self.mtgt), 1))
        self.beh = F.normalize(beh / cnt.clamp(min=1), dim=1)

    def edges(self, tau=None, k=None, gen=None):
        keep = torch.ones(len(self.mtgt), dtype=torch.bool)
        if tau is not None and tau > 0: keep = self.s[self.mflow] >= tau
        idx = torch.nonzero(keep).squeeze(1)
        if k is not None and len(idx):
            pri = torch.rand(len(idx), generator=gen)
            tg = self.mtgt[idx].numpy(); order = np.lexsort((pri.numpy(), tg)); tgs = tg[order]
            first = np.r_[0, np.nonzero(np.diff(tgs))[0] + 1]; start = np.repeat(first, np.diff(np.r_[first, len(tgs)]))
            rank = np.arange(len(tgs)) - start
            idx = idx[torch.tensor(order[rank < k])]
        return self.msrc[idx], self.mtgt[idx], self.mflow[idx]

def seg_softmax(logits, tgt, n):
    mx = torch.full((n, logits.shape[1]), -1e30).scatter_reduce(0, tgt[:, None].expand_as(logits), logits, 'amax', include_self=True)
    ex = torch.exp(logits - mx[tgt]); den = torch.zeros(n, logits.shape[1]).index_add_(0, tgt, ex)
    return ex / (den[tgt] + 1e-16)

# ------------------------------------------------------------------ graph layers
class AegisLayer(nn.Module):
    """Algorithm 2: edge-aware multi-head attention over the gated, sampled neighbourhood."""
    def __init__(self, d, de, heads=4, drop=0.5):
        super().__init__(); self.h = heads; self.dh = d // heads
        self.W = nn.Linear(2 * d + de, d); self.a = nn.Parameter(torch.randn(heads, self.dh) * 0.1)
        self.Wv = nn.Linear(d + de, d); self.Wo = nn.Linear(2 * d, d); self.drop = nn.Dropout(drop)
    def forward(self, h, e, src, tgt, flow):
        z = self.W(torch.cat([h[src], h[tgt], e[flow]], 1)).view(-1, self.h, self.dh)
        al = seg_softmax(F.leaky_relu((z * self.a).sum(-1), 0.2), tgt, h.shape[0]); al = self.drop(al)
        m = (self.Wv(torch.cat([h[src], e[flow]], 1)).view(-1, self.h, self.dh) * al[..., None]).view(-1, self.h * self.dh)
        agg = torch.zeros(h.shape[0], m.shape[1]).index_add_(0, tgt, m)
        return F.elu(self.Wo(torch.cat([h, agg], 1)))

class SageLayer(nn.Module):
    def __init__(self, d, de):
        super().__init__(); self.Wm = nn.Linear(d + de, d); self.Wo = nn.Linear(2 * d, d)
    def forward(self, h, e, src, tgt, flow):
        m = self.Wm(torch.cat([h[src], e[flow]], 1))
        agg = torch.zeros(h.shape[0], m.shape[1]).index_add_(0, tgt, m)
        cnt = torch.zeros(h.shape[0], 1).index_add_(0, tgt, torch.ones(len(tgt), 1)).clamp(min=1)
        return F.relu(self.Wo(torch.cat([h, agg / cnt], 1)))

class GatLayer(nn.Module):
    """GAT attention on node states; optional behaviour-similarity bias (BS-GAT)."""
    def __init__(self, d, de, heads, drop=0.5):
        super().__init__(); self.h = heads; self.dh = d // heads
        self.W = nn.Linear(d, d); self.as_ = nn.Parameter(torch.randn(heads, self.dh) * 0.1); self.at = nn.Parameter(torch.randn(heads, self.dh) * 0.1)
        self.Wv = nn.Linear(d + de, d); self.Wo = nn.Linear(2 * d, d); self.drop = nn.Dropout(drop)
    def forward(self, h, e, src, tgt, flow, bias=None):
        wh = self.W(h).view(-1, self.h, self.dh)
        lg = F.leaky_relu((wh[src] * self.as_).sum(-1) + (wh[tgt] * self.at).sum(-1), 0.2)
        if bias is not None: lg = lg + bias[:, None]
        al = self.drop(seg_softmax(lg, tgt, h.shape[0]))
        m = (self.Wv(torch.cat([h[src], e[flow]], 1)).view(-1, self.h, self.dh) * al[..., None]).view(-1, self.h * self.dh)
        agg = torch.zeros(h.shape[0], m.shape[1]).index_add_(0, tgt, m)
        return F.elu(self.Wo(torch.cat([h, agg], 1)))

class GraphEncoder(nn.Module):
    """kind: aegis | sage | gat | bsgat.  Returns one embedding per flow (edge)."""
    CFG = {'aegis': dict(layers=3, d=128, heads=4, tau=TAU, k=25), 'sage': dict(layers=2, d=128, heads=1, tau=None, k=10),
           'gat': dict(layers=2, d=64, heads=2, tau=None, k=None), 'bsgat': dict(layers=2, d=128, heads=4, tau=None, k=None)}
    def __init__(self, kind, de, tau=None):
        super().__init__(); c = dict(self.CFG[kind]); self.kind = kind
        if tau is not None: c['tau'] = tau
        self.c = c; d = c['d']
        self.inp = nn.Linear(2, d); self.ep = nn.Linear(de, d)
        mk = {'aegis': lambda: AegisLayer(d, de, c['heads']), 'sage': lambda: SageLayer(d, de),
              'gat': lambda: GatLayer(d, de, c['heads']), 'bsgat': lambda: GatLayer(d, de, c['heads'])}[kind]
        self.layers = nn.ModuleList([mk() for _ in range(c['layers'])])
        self.head = nn.Sequential(nn.Linear(3 * d, 128), nn.ReLU(), nn.Dropout(0.2), nn.Linear(128, 128), nn.ReLU())
        self.out_dim = 128
    def forward(self, g, gen=None):
        h = F.relu(self.inp(g.x))
        for L in self.layers:
            src, tgt, flow = g.edges(self.c['tau'], self.c['k'], gen)   # resampled for every layer and epoch
            if self.kind == 'bsgat':
                w = ((g.beh[src] * g.beh[tgt]).sum(1) + 1) / 2; h = L(h, g.e, src, tgt, flow, torch.log(w + 1e-4))
            else: h = L(h, g.e, src, tgt, flow)
        return self.head(torch.cat([h[g.fsrc], h[g.fdst], F.relu(self.ep(g.e))], 1))

class GraphClassifier(nn.Module):
    def __init__(self, kind, de, tau=None):
        super().__init__(); self.enc = GraphEncoder(kind, de, tau); self.cls = nn.Linear(128, 1)
    def forward(self, g, t=None, gen=None):
        return self.cls(self.enc(g, gen)).squeeze(1), None

class Hybrid(nn.Module):
    """GraphAEGIS flow embedding + retrieved ThreatOrator embedding, adaptive gated fusion (Eqs. 14-18)."""
    def __init__(self, de, dt, fusion='gate', tau=None, shared=256):
        super().__init__(); self.enc = GraphEncoder('aegis', de, tau); self.fusion = fusion
        self.WT = nn.Linear(dt, shared); self.WG = nn.Linear(128, shared)
        self.Wz = nn.Linear(2 * shared, shared); self.cls = nn.Linear(shared if fusion == 'gate' else 2 * shared, 1)
    def forward(self, g, t, gen=None):
        tp, gp = self.WT(t), self.WG(self.enc(g, gen))
        if self.fusion == 'gate':
            z = torch.sigmoid(self.Wz(torch.cat([tp, gp], 1))); v = z * tp + (1 - z) * gp
            return self.cls(v).squeeze(1), z.mean(1)
        return self.cls(torch.cat([tp, gp], 1)).squeeze(1), None

class TextOnly(nn.Module):
    def __init__(self, dt, shared=256):
        super().__init__(); self.net = nn.Sequential(nn.Linear(dt, shared), nn.ReLU(), nn.Linear(shared, 1))
    def forward(self, g, t, gen=None): return self.net(t).squeeze(1), None

# ------------------------------------------------------------------ tabular baselines
class DNN(nn.Module):
    def __init__(self, d):
        super().__init__(); self.net = nn.Sequential(nn.Linear(d, 128), nn.ReLU(), nn.Dropout(0.3), nn.Linear(128, 64), nn.ReLU(),
                                                     nn.Dropout(0.3), nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, 1))
    def forward(self, x): return self.net(x).squeeze(1)

class CNN(nn.Module):
    def __init__(self, d):
        super().__init__()
        self.conv = nn.Sequential(nn.Conv1d(1, 32, 3, padding=1), nn.ReLU(), nn.MaxPool1d(2), nn.Conv1d(32, 64, 3, padding=1), nn.ReLU(), nn.AdaptiveMaxPool1d(8))
        self.fc = nn.Sequential(nn.Linear(64 * 8, 64), nn.ReLU(), nn.Dropout(0.3), nn.Linear(64, 1))
    def forward(self, x): return self.fc(self.conv(x[:, None, :]).flatten(1)).squeeze(1)

class LSTMNet(nn.Module):
    def __init__(self, d):
        super().__init__(); self.lstm = nn.LSTM(d, 128, num_layers=2, batch_first=True, dropout=0.2); self.fc = nn.Linear(128, 1)
    def forward(self, x): return self.fc(self.lstm(x)[0][:, -1]).squeeze(1)

def sequences(df, L=10):
    """For every flow: indices of the previous L-1 flows of the same source IP (time order, same partition), then itself."""
    order = np.lexsort((df['t'].values, df['src'].values)); src = df['src'].values[order]
    first = np.r_[0, np.nonzero(src[1:] != src[:-1])[0] + 1]; start = np.repeat(first, np.diff(np.r_[first, len(src)]))
    pos = np.arange(len(src)); seq = np.full((len(src), L), -1)
    for j in range(L):
        back = L - 1 - j; ok = pos - back >= start
        seq[ok, j] = order[pos[ok] - back]
    out = np.full((len(df), L), -1); out[order] = seq
    return out
