# -*- coding: utf-8 -*-
"""Step 1. Documented, seeded subsample of each dataset, flow features, 60-s host windows and the 10 folds.

Sampling scheme (per dataset, seed 42): N_TOTAL flows; 60% benign drawn at random; 40% attacks, where every attack
family first receives all of its flows up to RARE_CAP, and the remaining attack budget is split over the families in
proportion to the number of flows they have left in the full dataset.
"""
import os, sys, json, argparse
import numpy as np, pandas as pd
from sklearn.model_selection import StratifiedKFold

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, '..', 'data')
SEED = 42
FAMILIES = ['Fuzzers', 'Analysis', 'Backdoors', 'DoS', 'Exploits', 'Generic', 'Reconnaissance', 'Shellcode', 'Worms']
INTERNAL = ('59.166.0.', '149.171.126.')     # UNSW-NB15 testbed subnets (Moustafa & Slay 2015)
TOP_PORTS = [80, 53, 111, 25, 21, 22, 445, 143, 110, 179, 5060, 6881, 1723, 520, 514, 0, 443, 23, 139, 161]

def load_unsw():
    df = pd.read_parquet(os.path.join(DATA, 'raw_alt.parquet'))
    df.columns = [c.strip() for c in df.columns]
    df = df[df['srcip'].astype(str) != 'srcip']           # header lines repeated inside the concatenated CSV files
    fam = df['attack_cat'].astype(str).str.strip().replace({'Backdoor': 'Backdoors', 'nan': 'Normal', '': 'Normal'})
    fam = fam.where(df['Label'].astype(int) == 1, 'Benign')
    out = pd.DataFrame({'src': df['srcip'].astype(str), 'dst': df['dstip'].astype(str),
                        'dport': pd.to_numeric(df['dsport'], errors='coerce').fillna(-1).astype(int),
                        'proto': df['proto'].astype(str).str.lower(), 't': pd.to_numeric(df['Stime'], errors='coerce').astype(float),
                        'family': fam.values, 'label': (fam.values != 'Benign').astype(int)})
    num_cols = ['dur', 'sbytes', 'dbytes', 'sttl', 'dttl', 'sloss', 'dloss', 'Sload', 'Dload', 'Spkts', 'Dpkts', 'swin', 'dwin',
                'stcpb', 'dtcpb', 'smeansz', 'dmeansz', 'trans_depth', 'res_bdy_len', 'Sjit', 'Djit', 'Sintpkt', 'Dintpkt', 'tcprtt',
                'synack', 'ackdat', 'is_sm_ips_ports', 'ct_state_ttl', 'ct_flw_http_mthd', 'is_ftp_login', 'ct_ftp_cmd', 'ct_srv_src',
                'ct_srv_dst', 'ct_dst_ltm', 'ct_src_ltm', 'ct_src_dport_ltm', 'ct_dst_sport_ltm', 'ct_dst_src_ltm']
    for c in num_cols: out['f_' + c] = pd.to_numeric(df[c], errors='coerce').fillna(0).astype(float).values
    out['c_state'] = df['state'].astype(str).values; out['c_service'] = df['service'].astype(str).values
    # packet / byte / duration columns used by the early-detection truncation
    out.attrs['pkt'] = ('f_Spkts', 'f_Dpkts'); out.attrs['byt'] = ('f_sbytes', 'f_dbytes'); out.attrs['dur'] = ['f_dur']
    return out

def load_nf():
    df = pd.read_parquet(os.path.join(DATA, 'NF-UNSW-NB15-v3.parquet'))
    fam = df['Attack'].astype(str).replace({'Backdoor': 'Backdoors'})
    pmap = {6: 'tcp', 17: 'udp', 1: 'icmp'}
    out = pd.DataFrame({'src': df['IPV4_SRC_ADDR'].astype(str), 'dst': df['IPV4_DST_ADDR'].astype(str),
                        'dport': df['L4_DST_PORT'].astype(int), 'proto': df['PROTOCOL'].map(pmap).fillna('other').values,
                        't': df['FLOW_START_MILLISECONDS'].astype(float) / 1000.0,
                        'family': fam.values, 'label': df['Label'].astype(int).values})
    drop = {'FLOW_START_MILLISECONDS', 'FLOW_END_MILLISECONDS', 'IPV4_SRC_ADDR', 'L4_SRC_PORT', 'IPV4_DST_ADDR', 'L4_DST_PORT',
            'PROTOCOL', 'Label', 'Attack', 'DNS_QUERY_ID'}
    for c in df.columns:
        if c not in drop: out['f_' + c] = df[c].astype(float).values
    out.attrs['pkt'] = ('f_IN_PKTS', 'f_OUT_PKTS'); out.attrs['byt'] = ('f_IN_BYTES', 'f_OUT_BYTES')
    out.attrs['dur'] = ['f_FLOW_DURATION_MILLISECONDS', 'f_DURATION_IN', 'f_DURATION_OUT']
    return out

def subsample(df, n_total, rare_cap):
    rng = np.random.RandomState(SEED)
    n_att = int(round(0.4 * n_total)); n_ben = n_total - n_att
    counts = df['family'].value_counts()
    fams = [f for f in FAMILIES if f in counts.index]
    alloc = {f: int(min(counts[f], rare_cap)) for f in fams}           # every family: all flows up to RARE_CAP
    rest = n_att - sum(alloc.values()); spare = {f: counts[f] - alloc[f] for f in fams}
    tot = sum(spare.values())
    for f in fams: alloc[f] += int(min(spare[f], round(rest * spare[f] / tot)))   # remainder in proportion to the flows left
    idx = [rng.choice(np.where(df['family'].values == 'Benign')[0], n_ben, replace=False)]
    for f, k in alloc.items():
        idx.append(rng.choice(np.where(df['family'].values == f)[0], k, replace=False))
    idx = np.sort(np.concatenate(idx))
    return df.iloc[idx].reset_index(drop=True), alloc, counts.to_dict()

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--n', type=int, default=50000); ap.add_argument('--rare_cap', type=int, default=1500)
    a = ap.parse_args()
    os.makedirs(os.path.join(HERE, '..', 'prepared'), exist_ok=True)
    info = {}
    for name, loader in (('UNSW-NB15', load_unsw), ('NF-UNSW-NB15-v3', load_nf)):
        df = loader(); attrs = dict(df.attrs)
        sub, alloc, full_counts = subsample(df, a.n, a.rare_cap)
        sub['internal_src'] = sub['src'].str.startswith(INTERNAL).astype(int)
        sub['internal_dst'] = sub['dst'].str.startswith(INTERNAL).astype(int)
        sub['window'] = (sub['t'] // 60).astype(np.int64)
        skf = StratifiedKFold(10, shuffle=True, random_state=SEED)
        fold = np.zeros(len(sub), int)
        for k, (_, te) in enumerate(skf.split(sub, sub['family']), 1): fold[te] = k
        sub['fold'] = fold
        sub.attrs = {}
        sub.to_parquet(os.path.join(HERE, '..', 'prepared', f'{name}.parquet'))
        info[name] = {'full_rows': int(len(df)), 'full_family_counts': {k: int(v) for k, v in full_counts.items()},
                      'sample_rows': int(len(sub)), 'sample_family_counts': {k: int(v) for k, v in sub['family'].value_counts().items()},
                      'attrs': {k: list(v) for k, v in attrs.items()}}
        print(name, info[name]['sample_family_counts'])
    json.dump(info, open(os.path.join(HERE, '..', 'prepared', 'sampling_info.json'), 'w'), indent=1)

if __name__ == '__main__':
    main()
