#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
recompute_metrics.py - recompute every reported metric of the manuscript from saved predictions.

All values in Tables 2-6, Supplementary Table S2, the 95% confidence interval quoted in the
Results, and the paired t-test against GraphSAGE are produced by this script. Nothing is
typed in by hand.

INPUT (either A or B, under --data DIR)

A. Fold-wise predictions (preferred; required for AUC):
     DIR/<dataset>/<model>/fold<k>.csv      k = 1..10
   columns:  y_true  (0 = benign, 1 = malicious)
             y_prob  (predicted probability of the malicious class)
             y_pred  (optional; if absent y_pred = y_prob >= 0.5)

B. Fold-wise confusion matrices (AUC is then reported as "n/a"):
     DIR/confusion_matrices.csv
   columns:  dataset, model, fold, TP, TN, FP, FN

   <dataset> : UNSW-NB15 | NF-UNSW-NB15-v3
   <model>   : DNN-IDS | CNN-IDS | GraphSAGE | GAT-IDS | LSTM | BS-GAT | Hybrid
               (the former names AI-SecNet, Deep IDS and ZeroHunter are accepted and mapped)
               ThreatOrator | GraphAEGIS                         (Table 4)
               Hybrid-noDomainMask | Hybrid-noEdgeGating | Hybrid-concatFusion   (Table 5, UNSW-NB15)

Optional:
     DIR/logo/<family>/<model>.csv   (y_true all 1; family = Worms | Backdoors;
                                      model = GraphAEGIS | Hybrid)  -> Table 6 detection rates

OUTPUT (under --out DIR): Table2.md/.csv, Table3.md/.csv, Table4.md/.csv, Table5.md/.csv,
   TableS2_confusion_matrices.csv, Table6_LOGO.md (if LOGO files exist), stats.md,
   FigS1_fold_accuracy_boxplot.png (if matplotlib is installed).

CHECKS: for every fold, Accuracy must lie between Recall and Specificity, because
   Accuracy = w*Recall + (1-w)*Specificity, with w = (TP+FN)/N. A violation stops the script.

USAGE
   python recompute_metrics.py --data predictions/ --out recomputed/
   python recompute_metrics.py --check-reported      # audit of the values printed in the
                                                     # previous version of the manuscript
   python recompute_metrics.py --selftest            # synthetic data, tests the code only
"""
import argparse, csv, math, os, random, sys, statistics as st

DATASETS = ['UNSW-NB15', 'NF-UNSW-NB15-v3']
MAIN = ['GraphSAGE', 'CNN-IDS', 'DNN-IDS', 'LSTM', 'GAT-IDS', 'BS-GAT', 'Hybrid']
ALIASES = {'AI-SecNet': 'DNN-IDS', 'AI SecNet': 'DNN-IDS', 'Deep IDS': 'CNN-IDS', 'ZeroHunter': 'GAT-IDS'}  # names used before revision 2
def canon(model): return ALIASES.get(model.strip(), model.strip())
ABL = ['ThreatOrator', 'GraphAEGIS', 'Hybrid']
COMP = ['Hybrid', 'Hybrid-noDomainMask', 'Hybrid-noEdgeGating', 'Hybrid-concatFusion']
T975_DF9 = 2.262157  # t_{0.975, 9}

# ----------------------------------------------------------------------------- statistics
def betacf(a, b, x):
    m, qab, qap, qam = 1, a + b, a + 1, a - 1
    c, d = 1.0, 1 - qab * x / qap
    d = 1 / (d if abs(d) > 1e-300 else 1e-300); h = d
    for m in range(1, 300):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1 + aa * d; d = 1 / (d if abs(d) > 1e-300 else 1e-300)
        c = 1 + aa / c if abs(1 + aa / c) > 1e-300 else 1e-300
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1 + aa * d; d = 1 / (d if abs(d) > 1e-300 else 1e-300)
        c = 1 + aa / c if abs(1 + aa / c) > 1e-300 else 1e-300
        de = d * c; h *= de
        if abs(de - 1) < 1e-12: break
    return h

def betainc(a, b, x):
    if x <= 0: return 0.0
    if x >= 1: return 1.0
    lbt = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log(1 - x)
    if x < (a + 1) / (a + b + 2):
        return math.exp(lbt) * betacf(a, b, x) / a
    return 1 - math.exp(lbt) * betacf(b, a, 1 - x) / b

def t_two_sided_p(t, df):
    return betainc(df / 2, 0.5, df / (df + t * t))

def paired_t(a, b):
    d = [x - y for x, y in zip(a, b)]
    n = len(d); md = st.mean(d); sd = st.stdev(d)
    if sd == 0: return float('inf'), 0.0, md
    t = md / (sd / math.sqrt(n))
    return t, t_two_sided_p(abs(t), n - 1), md

def auc_from_probs(y, p):
    """Mann-Whitney AUC with average ranks for ties."""
    pairs = sorted(zip(p, y))
    ranks = [0.0] * len(pairs); i = 0
    while i < len(pairs):
        j = i
        while j + 1 < len(pairs) and pairs[j + 1][0] == pairs[i][0]: j += 1
        r = (i + j) / 2 + 1
        for k in range(i, j + 1): ranks[k] = r
        i = j + 1
    npos = sum(1 for _, t in pairs if t == 1); nneg = len(pairs) - npos
    if npos == 0 or nneg == 0: return float('nan')
    rpos = sum(r for r, (_, t) in zip(ranks, pairs) if t == 1)
    return (rpos - npos * (npos + 1) / 2) / (npos * nneg)

# ----------------------------------------------------------------------------- metrics
def fold_metrics(TP, TN, FP, FN, auc=None):
    N = TP + TN + FP + FN
    acc = (TP + TN) / N
    prec = TP / (TP + FP) if TP + FP else float('nan')
    rec = TP / (TP + FN) if TP + FN else float('nan')
    spec = TN / (TN + FP) if TN + FP else float('nan')
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else float('nan')
    return dict(TP=TP, TN=TN, FP=FP, FN=FN, Accuracy=acc, Precision=prec, Recall=rec,
                Specificity=spec, FPR=1 - spec, F1=f1, AUC=auc if auc is not None else float('nan'))

def check_bound(m, where):
    lo, hi = sorted([m['Recall'], m['Specificity']])
    if not (lo - 1e-12 <= m['Accuracy'] <= hi + 1e-12):
        raise SystemExit(f"CONSISTENCY ERROR {where}: accuracy {m['Accuracy']:.6f} not in [{lo:.6f}, {hi:.6f}]")

def summarize(folds, key):
    v = [f[key] for f in folds]
    if any(math.isnan(x) for x in v): return float('nan'), float('nan'), (float('nan'), float('nan'))
    m = st.mean(v); sd = st.stdev(v) if len(v) > 1 else 0.0
    t = T975_DF9 if len(v) == 10 else None
    if t is None:
        raise SystemExit(f'expected 10 folds, found {len(v)}')
    half = t * sd / math.sqrt(len(v))
    return m, sd, (m - half, m + half)

# ----------------------------------------------------------------------------- loading
def load_predictions(path):
    y, p, yp = [], [], []
    with open(path, newline='') as f:
        for row in csv.DictReader(f):
            y.append(int(float(row['y_true'])))
            pr = float(row['y_prob']) if row.get('y_prob') not in (None, '') else None
            p.append(pr)
            if row.get('y_pred') not in (None, ''): yp.append(int(float(row['y_pred'])))
            else: yp.append(int(pr >= 0.5))
    TP = sum(1 for a, b in zip(y, yp) if a == 1 and b == 1)
    TN = sum(1 for a, b in zip(y, yp) if a == 0 and b == 0)
    FP = sum(1 for a, b in zip(y, yp) if a == 0 and b == 1)
    FN = sum(1 for a, b in zip(y, yp) if a == 1 and b == 0)
    auc = auc_from_probs(y, p) if all(x is not None for x in p) else None
    return fold_metrics(TP, TN, FP, FN, auc)

def load_all(data):
    res = {}
    cmf = os.path.join(data, 'confusion_matrices.csv')
    if os.path.exists(cmf):
        with open(cmf, newline='') as f:
            for r in csv.DictReader(f):
                m = fold_metrics(int(r['TP']), int(r['TN']), int(r['FP']), int(r['FN']), None)
                res.setdefault((r['dataset'], canon(r['model'])), {})[int(r['fold'])] = m
    for ds in DATASETS:
        dd = os.path.join(data, ds)
        if not os.path.isdir(dd): continue
        for model in sorted(os.listdir(dd)):
            if model.startswith('_'): continue          # metadata folders
            md = os.path.join(dd, model)
            for fn in sorted(os.listdir(md)):
                if fn.startswith('fold') and fn.endswith('.csv'):
                    k = int(fn[4:-4])
                    res.setdefault((ds, canon(model)), {})[k] = load_predictions(os.path.join(md, fn))
    out = {}
    for key, folds in res.items():
        ks = sorted(folds)
        if ks != list(range(1, 11)):
            raise SystemExit(f'{key}: folds {ks}, expected 1..10')
        out[key] = [folds[k] for k in ks]
        for k, m in zip(ks, out[key]): check_bound(m, f'{key} fold {k}')
    return out

# ----------------------------------------------------------------------------- tables
def fmt(m, sd, pct=True, nd=2):
    if math.isnan(m): return 'n/a'
    if pct: return f'{100*m:.{nd}f} ± {100*sd:.{nd}f}'
    return f'{m:.4f} ± {sd:.4f}'

def write_table(path, header, rows):
    with open(path + '.csv', 'w', newline='') as f:
        w = csv.writer(f); w.writerow(header); w.writerows(rows)
    with open(path + '.md', 'w') as f:
        f.write('| ' + ' | '.join(header) + ' |\n|' + '---|' * len(header) + '\n')
        for r in rows: f.write('| ' + ' | '.join(r) + ' |\n')

def main_table(res, ds):
    hdr = ['Model', 'AUC', 'False Positive Rate', 'F1-Score (%)', 'Precision (%)', 'Recall (%)', 'Accuracy (%)']
    rows = []
    for model in MAIN:
        if (ds, model) not in res: rows.append([model] + ['MISSING'] * 6); continue
        f = res[(ds, model)]
        s = {k: summarize(f, k) for k in ('AUC', 'FPR', 'F1', 'Precision', 'Recall', 'Accuracy')}
        rows.append([model, fmt(*s['AUC'][:2], pct=False), fmt(*s['FPR'][:2], pct=False)] +
                    [fmt(*s[k][:2]) for k in ('F1', 'Precision', 'Recall', 'Accuracy')])
    return hdr, rows

def run(data, out):
    os.makedirs(out, exist_ok=True)
    res = load_all(data)
    for ds, name in zip(DATASETS, ['Table2', 'Table3']):
        write_table(os.path.join(out, name), *main_table(res, ds))
    # Table 4 (ablation; hybrid rows are the same per-fold values as Tables 2 and 3)
    rows = []
    for model in ABL:
        for ds in DATASETS:
            if (ds, model) not in res: rows.append([model, ds] + ['MISSING'] * 4); continue
            f = res[(ds, model)]
            rows.append([model, ds] + [fmt(*summarize(f, k)[:2]) for k in ('Accuracy', 'Precision', 'Recall', 'F1')])
    write_table(os.path.join(out, 'Table4'), ['Configuration', 'Dataset', 'Accuracy (%)', 'Precision (%)', 'Recall (%)', 'F1-Score (%)'], rows)
    rows = []
    for model in COMP:
        key = ('UNSW-NB15', model)
        if key not in res: rows.append([model] + ['MISSING'] * 4); continue
        rows.append([model] + [fmt(*summarize(res[key], k)[:2]) for k in ('Accuracy', 'Precision', 'Recall', 'F1')])
    write_table(os.path.join(out, 'Table5'), ['Model configuration', 'Accuracy (%)', 'Precision (%)', 'Recall (%)', 'F1-Score (%)'], rows)
    # Supplementary Table S2
    with open(os.path.join(out, 'TableS2_confusion_matrices.csv'), 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['dataset', 'model', 'fold', 'TP', 'TN', 'FP', 'FN', 'Accuracy', 'Precision', 'Recall', 'Specificity', 'FPR', 'F1', 'AUC'])
        for (ds, model), folds in sorted(res.items()):
            for k, m in enumerate(folds, 1):
                w.writerow([ds, model, k] + [m[x] for x in ('TP', 'TN', 'FP', 'FN')] +
                           [f"{m[x]:.6f}" for x in ('Accuracy', 'Precision', 'Recall', 'Specificity', 'FPR', 'F1', 'AUC')])
    # statistics quoted in the text
    lines = ['# Statistics quoted in the manuscript\n']
    for ds in DATASETS:
        if (ds, 'Hybrid') in res:
            m, sd, (lo, hi) = summarize(res[(ds, 'Hybrid')], 'Accuracy')
            lines.append(f'- {ds}, Hybrid accuracy: {100*m:.2f}% ± {100*sd:.2f} (SD); 95% CI (t, df = 9) [{100*lo:.2f}%, {100*hi:.2f}%]')
        if (ds, 'Hybrid') in res and (ds, 'GraphSAGE') in res:
            a = [f['Accuracy'] for f in res[(ds, 'Hybrid')]]; b = [f['Accuracy'] for f in res[(ds, 'GraphSAGE')]]
            t, p, md = paired_t(a, b)
            lines.append(f'- {ds}, paired t-test Hybrid vs GraphSAGE (fold-wise accuracy): mean difference {100*md:.2f} pp, t(9) = {t:.3f}, p = {p:.4g}')
        for other in ('BS-GAT',):
            if (ds, 'Hybrid') in res and (ds, other) in res:
                d = 100 * (summarize(res[(ds, 'Hybrid')], 'Accuracy')[0] - summarize(res[(ds, other)], 'Accuracy')[0])
                lines.append(f'- {ds}, accuracy difference Hybrid - {other}: {d:.2f} pp (no significance test reported in the manuscript)')
    # LOGO
    logo = os.path.join(data, 'logo')
    if os.path.isdir(logo):
        rows = []
        for fam in sorted(os.listdir(logo)):
            for model in ('GraphAEGIS', 'Hybrid'):
                pth = os.path.join(logo, fam, model + '.csv')
                if os.path.exists(pth):
                    m = load_predictions(pth)
                    rec = m['TP'] / (m['TP'] + m['FN'])
                    rows.append([fam, model, f'{100*rec:.1f}%', f'{100*(1-rec):.1f}%'])
        write_table(os.path.join(out, 'Table6_LOGO'), ['Held-out family', 'Model', 'Detection rate (recall)', 'FNR'], rows)
    open(os.path.join(out, 'stats.md'), 'w').write('\n'.join(lines) + '\n')
    # box plot (Supplementary Fig. S1)
    try:
        import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
        fig, axes = plt.subplots(1, 2, figsize=(11, 4), sharey=True)
        for ax, ds in zip(axes, DATASETS):
            models = [m for m in MAIN if (ds, m) in res]
            ax.boxplot([[100 * f['Accuracy'] for f in res[(ds, m)]] for m in models]); ax.set_xticks(range(1, len(models) + 1)); ax.set_xticklabels(models)
            ax.set_title(ds); ax.set_ylabel('Fold accuracy (%)'); ax.tick_params(axis='x', rotation=45)
        fig.tight_layout(); fig.savefig(os.path.join(out, 'FigS1_fold_accuracy_boxplot.png'), dpi=300)
    except ImportError:
        print('matplotlib not installed: box plot skipped')
    print('\n'.join(lines))
    print(f'tables written to {out}')

# ----------------------------------------------------------------------------- audit of reported values
REPORTED = {  # values printed in Tables 2 and 3 of the previous version (mean values only)
    'UNSW-NB15': {'GraphSAGE': (0.0654, 94.40, 94.69, 94.12, 97.71), 'Deep IDS': (0.0508, 89.79, 89.43, 90.15, 91.52),
                  'AI-SecNet': (0.0956, 89.72, 91.32, 88.17, 92.04), 'LSTM': (0.0997, 91.96, 93.90, 90.10, 95.61),
                  'ZeroHunter': (0.0927, 89.60, 88.90, 90.32, 90.53), 'BS-GAT': (0.0310, 97.85, 98.10, 97.60, 98.92),
                  'Hybrid': (0.0224, 98.30, 99.17, 97.44, 99.46)},
    'NF-UNSW-NB15-V2': {'ZeroHunter': (0.0697, 93.50, 93.90, 93.11, 96.53), 'Deep IDS': (0.0590, 92.47, 93.66, 91.31, 94.72),
                        'AI-SecNet': (0.0613, 91.63, 90.43, 92.87, 95.87), 'GraphSAGE': (0.0404, 96.72, 97.69, 95.76, 97.99),
                        'LSTM': (0.0619, 94.99, 95.90, 94.09, 96.61), 'BS-GAT': (0.0295, 97.80, 98.50, 97.10, 99.15),
                        'Hybrid': (0.0269, 98.66, 99.40, 97.94, 99.66)},
}
def check_reported():
    print('Audit of the mean values printed in Tables 2 and 3 of the previous version')
    print('Rule: Accuracy must lie between Recall and Specificity (= 1 - FPR) for any confusion matrix.')
    print('With stratified folds the attack proportion w is the same in every fold, so the mean accuracy equals')
    print('w * mean Recall + (1 - w) * mean Specificity and must also lie between the two means.\n')
    bad = 0
    for ds, rows in REPORTED.items():
        for model, (fpr, f1, prec, rec, acc) in rows.items():
            spec = 100 * (1 - fpr)
            lo, hi = sorted([rec, spec])
            ok = lo <= acc <= hi
            f1c = 2 * prec * rec / (prec + rec)
            bad += (not ok)
            print(f'{ds:16s} {model:11s} Recall {rec:6.2f}  Spec {spec:6.2f}  Acc {acc:6.2f}  -> {"OK " if ok else "VIOLATION"}   '
                  f'F1 from mean P,R {f1c:6.2f} vs printed {f1:6.2f}')
    print(f'\n{bad} of 14 rows violate the bound.')

# ----------------------------------------------------------------------------- self-test
def selftest():
    import tempfile
    rnd = random.Random(0)
    d = tempfile.mkdtemp()
    for ds in DATASETS:
        for model in MAIN + ['ThreatOrator', 'GraphAEGIS'] + COMP[1:]:
            if model in COMP[1:] and ds != 'UNSW-NB15': continue
            q = 0.9 if model.startswith('Hybrid') else 0.8
            os.makedirs(os.path.join(d, ds, model))
            for k in range(1, 11):
                with open(os.path.join(d, ds, model, f'fold{k}.csv'), 'w', newline='') as f:
                    w = csv.writer(f); w.writerow(['y_true', 'y_prob'])
                    for _ in range(400):
                        y = int(rnd.random() < 0.4)
                        p = min(1, max(0, rnd.gauss(q if y else 1 - q, 0.2)))
                        w.writerow([y, f'{p:.4f}'])
    run(d, os.path.join(d, 'out'))
    print('SELF-TEST on synthetic data finished (these numbers are synthetic and must not be reported).')

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--data'); ap.add_argument('--out', default='recomputed')
    ap.add_argument('--check-reported', action='store_true'); ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.check_reported: check_reported()
    elif a.selftest: selftest()
    elif a.data: run(a.data, a.out)
    else: ap.print_help()
