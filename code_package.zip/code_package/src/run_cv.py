# -*- coding: utf-8 -*-
"""Step 4. Stratified 10-fold CV of all models; saves fold-wise predictions (recompute_metrics.py layout), learning curves,
gate values, early-detection and noise-robustness results."""
import os, sys, json, time, argparse
import numpy as np, pandas as pd, torch, torch.nn.functional as F
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import models as M, threatorator as T

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
EPOCHS_G, EPOCHS_TAB, BS_TAB, LR = 40, 20, 512, 1e-3

def save_pred(ds, model, k, y, p, extra=None):
    d = os.path.join(ROOT, 'predictions', ds, model); os.makedirs(d, exist_ok=True)
    df = pd.DataFrame({'y_true': y.astype(int), 'y_prob': p, 'y_pred': (p >= 0.5).astype(int)})
    df.to_csv(os.path.join(d, f'fold{k}.csv'), index=False)

def acc(y, p): return float(((p >= 0.5).astype(int) == y).mean())

def train_graph(model, gtr, ytr, ttr, gva, yva, tva, seed, epochs=None):
    epochs = epochs or EPOCHS_G; torch.manual_seed(seed); gen = torch.Generator().manual_seed(seed)
    opt = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-4)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs, eta_min=1e-6)
    ytr_t = torch.tensor(ytr, dtype=torch.float32); curve = []
    for ep in range(epochs):
        model.train(); lo, _ = model(gtr, ttr, gen); loss = F.binary_cross_entropy_with_logits(lo, ytr_t)
        opt.zero_grad(); loss.backward(); opt.step(); sch.step()
        if ep % 2 == 1 or ep == epochs - 1:
            pv, _ = predict_graph(model, gva, tva, seed)
            vl = float(F.binary_cross_entropy(torch.tensor(pv).clamp(1e-7, 1 - 1e-7), torch.tensor(yva, dtype=torch.float32)))
            curve.append({'epoch': ep + 1, 'train_loss': float(loss), 'train_acc': acc(ytr, torch.sigmoid(lo).detach().numpy()),
                          'val_loss': vl, 'val_acc': acc(yva, pv)})
    return curve

@torch.no_grad()
def predict_graph(model, g, t, seed=0, return_gate=False):
    model.eval(); gen = torch.Generator().manual_seed(seed)
    lo, z = model(g, t, gen); p = torch.sigmoid(lo).numpy()
    return (p, None if z is None else z.numpy()) if return_gate else (p, None)

def train_tab(model, Xtr, ytr, Xva, yva, seed, epochs=EPOCHS_TAB):
    torch.manual_seed(seed); opt = torch.optim.Adam(model.parameters(), lr=LR)
    Xtr_t, ytr_t = torch.tensor(Xtr), torch.tensor(ytr, dtype=torch.float32); curve = []
    rng = np.random.RandomState(seed)
    for ep in range(epochs):
        model.train(); perm = rng.permutation(len(Xtr)); tl, tc = 0.0, 0
        for i in range(0, len(perm), BS_TAB):
            b = torch.tensor(perm[i:i + BS_TAB]); lo = model(Xtr_t[b]); loss = F.binary_cross_entropy_with_logits(lo, ytr_t[b])
            opt.zero_grad(); loss.backward(); opt.step(); tl += float(loss) * len(b); tc += int(((lo > 0).float() == ytr_t[b]).sum())
        pv = predict_tab(model, Xva)
        vl = float(F.binary_cross_entropy(torch.tensor(pv).clamp(1e-7, 1 - 1e-7), torch.tensor(yva, dtype=torch.float32)))
        curve.append({'epoch': ep + 1, 'train_loss': tl / len(perm), 'train_acc': tc / len(perm), 'val_loss': vl, 'val_acc': acc(yva, pv)})
    return curve

@torch.no_grad()
def predict_tab(model, X, bs=4096):
    model.eval(); X = torch.tensor(X)
    return np.concatenate([torch.sigmoid(model(X[i:i + bs])).numpy() for i in range(0, len(X), bs)])

def seqX(X, seq):
    Xp = np.concatenate([X, np.zeros((1, X.shape[1]), np.float32)]); return Xp[np.where(seq < 0, len(X), seq)]

def truncate(df, attrs, N):
    """Early detection (approximation): flow records give totals only, so a flow with P > N packets is scaled to its
    first N packets proportionally (packet counts, byte counts, durations and packet-size histograms x N/P)."""
    d = df.copy(); P = (d[attrs['pkt'][0]] + d[attrs['pkt'][1]]).values.astype(float)
    f = np.where(P > N, N / np.maximum(P, 1), 1.0)
    cols = list(attrs['pkt']) + list(attrs['byt']) + list(attrs['dur'])
    cols += [c for c in d.columns if c.startswith('f_NUM_PKTS_') or c.startswith('f_RETRANSMITTED_')]
    for c in cols: d[c] = d[c].values * f
    return d

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--ds', required=True); ap.add_argument('--folds', default='1-10')
    ap.add_argument('--models', default='all'); ap.add_argument('--epochs_g', type=int, default=40); a = ap.parse_args()
    global EPOCHS_G; EPOCHS_G = a.epochs_g
    torch.set_num_threads(int(os.environ.get('NTHREADS', '4')))
    df = pd.read_parquet(os.path.join(ROOT, 'prepared', f'{a.ds}.parquet'))
    info = json.load(open(os.path.join(ROOT, 'prepared', 'sampling_info.json')))[a.ds]; attrs = info['attrs']
    lo_, hi_ = map(int, a.folds.split('-'))
    is_unsw = a.ds == 'UNSW-NB15'
    want = (lambda m: True) if a.models == 'all' else (lambda m: m in a.models.split(','))
    TEXT_MODELS = ('ThreatOrator', 'Hybrid', 'Hybrid-noDomainMask', 'Hybrid-noEdgeGating', 'Hybrid-concatFusion')
    if any(want(m) for m in TEXT_MODELS):
        text = {'mask': T.lookup('mask', df['dport'].values, df['proto'].values)}
        if is_unsw and want('Hybrid-noDomainMask'): text['nomask'] = T.lookup('nomask', df['dport'].values, df['proto'].values)
    else:
        text = {'mask': (np.zeros((len(df), 512), np.float32), np.zeros(len(df), int))}
    tsrc = text['mask'][1]
    for k in range(lo_, hi_ + 1):
        t0 = time.time(); seed = 42 + k
        te = df['fold'].values == k; trall = ~te
        rng = np.random.RandomState(seed); tr_idx = np.where(trall)[0]; rng.shuffle(tr_idx)
        nva = len(tr_idx) // 10; va = np.zeros(len(df), bool); va[tr_idx[:nva]] = True; tr = trall & ~va
        P = M.Prep().fit(df[tr]); X = {n: P.transform(df[m]) for n, m in (('tr', tr), ('va', va), ('te', te))}
        y = {n: df['label'].values[m] for n, m in (('tr', tr), ('va', va), ('te', te))}
        sc = M.EdgeScorer().fit(X['tr'], y['tr']); S = {n: sc.score(X[n]) for n in X}
        G = {n: M.Graph(df[m].reset_index(drop=True), X[n], S[n]) for n, m in (('tr', tr), ('va', va), ('te', te))}
        Tt = {tag: {n: torch.tensor(v[0][m]) for n, m in (('tr', tr), ('va', va), ('te', te))} for tag, v in text.items()}
        meta = {'fold': k, 'n_train': int(tr.sum()), 'n_val': int(va.sum()), 'n_test': int(te.sum()),
                'edges_below_tau_train': float((S['tr'] < M.TAU).mean()),
                'attack_edges_retained_train': float((S['tr'][y['tr'] == 1] >= M.TAU).mean()),
                'benign_edges_removed_train': float((S['tr'][y['tr'] == 0] < M.TAU).mean()),
                'text_lookup_level_test': {str(l): int((tsrc[te] == l).sum()) for l in range(4)},
                'nodes_test': int(G['te'].n_nodes)}
        fam_te = df['family'].values[te]
        md = os.path.join(ROOT, 'predictions', a.ds, '_meta'); os.makedirs(md, exist_ok=True)
        pd.DataFrame({'family': fam_te, 'y_true': y['te']}).to_csv(os.path.join(md, f'fold{k}_families.csv'), index=False)
        logs = {}; extra = {}
        # ---- tabular baselines
        for name, cls in (('DNN-IDS', M.DNN), ('CNN-IDS', M.CNN)):
            if not want(name): continue
            m = cls(X['tr'].shape[1]); logs[name] = train_tab(m, X['tr'], y['tr'], X['va'], y['va'], seed)
            save_pred(a.ds, name, k, y['te'], predict_tab(m, X['te']))
        if want('LSTM'):
            sq = {n: M.sequences(df[msk].reset_index(drop=True)) for n, msk in (('tr', tr), ('va', va), ('te', te))}
            Xs = {n: seqX(X[n], sq[n]) for n in X}
            m = M.LSTMNet(X['tr'].shape[1]); logs['LSTM'] = train_tab(m, Xs['tr'], y['tr'], Xs['va'], y['va'], seed)
            save_pred(a.ds, 'LSTM', k, y['te'], predict_tab(m, Xs['te']))
            if is_unsw:
                extra['early_LSTM'] = {}
                for N in (5, 10, 20, 50):
                    d2 = truncate(df[te].reset_index(drop=True), attrs, N); X2 = P.transform(d2)
                    extra['early_LSTM'][N] = acc(y['te'], predict_tab(m, seqX(X2, sq['te'])))
                extra['early_LSTM']['full'] = acc(y['te'], predict_tab(m, Xs['te']))
        # ---- graph models
        de = X['tr'].shape[1]; dt = text['mask'][0].shape[1]
        specs = [('GraphSAGE', lambda: M.GraphClassifier('sage', de), 'mask'), ('GAT-IDS', lambda: M.GraphClassifier('gat', de), 'mask'),
                 ('BS-GAT', lambda: M.GraphClassifier('bsgat', de), 'mask'), ('GraphAEGIS', lambda: M.GraphClassifier('aegis', de), 'mask'),
                 ('ThreatOrator', lambda: M.TextOnly(dt), 'mask'), ('Hybrid', lambda: M.Hybrid(de, dt), 'mask')]
        if is_unsw:
            specs += [('Hybrid-noDomainMask', lambda: M.Hybrid(de, dt), 'nomask'), ('Hybrid-noEdgeGating', lambda: M.Hybrid(de, dt, tau=0.0), 'mask'),
                      ('Hybrid-concatFusion', lambda: M.Hybrid(de, dt, fusion='concat'), 'mask')]
        for name, mk, tag in specs:
            if not want(name): continue
            ts = time.time(); m = mk()
            logs[name] = train_graph(m, G['tr'], y['tr'], Tt[tag]['tr'], G['va'], y['va'], Tt[tag]['va'], seed)
            p, z = predict_graph(m, G['te'], Tt[tag]['te'], seed, return_gate=True)
            save_pred(a.ds, name, k, y['te'], p)
            extra[f'time_{name}'] = time.time() - ts
            if name == 'Hybrid' and z is not None:
                extra['gate_by_family'] = {f: float(z[fam_te == f].mean()) for f in np.unique(fam_te)}
            if name in ('Hybrid', 'GraphAEGIS'):
                if is_unsw:
                    extra[f'early_{name}'] = {}
                    for N in (5, 10, 20, 50):
                        d2 = truncate(df[te].reset_index(drop=True), attrs, N); X2 = P.transform(d2)
                        g2 = M.Graph(d2, X2, sc.score(X2))
                        extra[f'early_{name}'][N] = acc(y['te'], predict_graph(m, g2, Tt[tag]['te'], seed)[0])
                    extra[f'early_{name}']['full'] = acc(y['te'], p)
                else:
                    rs = np.random.RandomState(seed); X2 = X['te'] + rs.normal(0, 0.1, X['te'].shape).astype(np.float32)
                    g2 = M.Graph(df[te].reset_index(drop=True), X2, sc.score(X2))
                    extra[f'noise_{name}'] = {'clean': acc(y['te'], p), 'noisy': acc(y['te'], predict_graph(m, g2, Tt[tag]['te'], seed)[0])}
        meta.update(extra); meta['seconds'] = time.time() - t0
        ld = os.path.join(ROOT, 'logs', a.ds); os.makedirs(ld, exist_ok=True)
        tagm = '' if a.models == 'all' else '_' + a.models.replace(',', '+')
        json.dump({'meta': meta, 'curves': logs}, open(os.path.join(ld, f'fold{k}{tagm}.json'), 'w'), indent=1)
        print(f'[{a.ds}] fold {k} done in {meta["seconds"]:.0f}s', {n: round(acc(y['te'], pd.read_csv(os.path.join(ROOT, "predictions", a.ds, n, f"fold{k}.csv"))["y_prob"].values), 4) for n in logs}, flush=True)

if __name__ == '__main__':
    main()
