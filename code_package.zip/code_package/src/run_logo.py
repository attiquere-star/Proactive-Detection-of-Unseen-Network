# -*- coding: utf-8 -*-
"""Step 5. Leave-one-group-out (Worms, Backdoors) on UNSW-NB15.
Training: all sampled flows except (i) every flow of the held-out family and (ii) the benign flows of fold 1.
Test: every sampled flow of the held-out family plus the benign flows of fold 1 (graph context and false-alarm rate).
ThreatOrator for model F is fine-tuned without the documents labelled F, and its retrieval index excludes them."""
import os, sys, json, numpy as np, pandas as pd, torch
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import models as M, threatorator as T, run_cv as R
ROOT = R.ROOT

def main():
    torch.set_num_threads(int(os.environ.get('NTHREADS', '4')))
    df = pd.read_parquet(os.path.join(ROOT, 'prepared', 'UNSW-NB15.parquet')); res = {}
    for fam in ('Worms', 'Backdoors'):
        seed = 4242
        test = (df['family'].values == fam) | ((df['family'].values == 'Benign') & (df['fold'].values == 1))
        train_all = ~test & (df['family'].values != fam)
        idx = np.where(train_all)[0]; rng = np.random.RandomState(seed); rng.shuffle(idx)
        va = np.zeros(len(df), bool); va[idx[:len(idx) // 10]] = True; tr = train_all & ~va
        P = M.Prep().fit(df[tr]); X = {n: P.transform(df[m]) for n, m in (('tr', tr), ('va', va), ('te', test))}
        y = {n: df['label'].values[m] for n, m in (('tr', tr), ('va', va), ('te', test))}
        sc = M.EdgeScorer().fit(X['tr'], y['tr'])
        G = {n: M.Graph(df[m].reset_index(drop=True), X[n], sc.score(X[n])) for n, m in (('tr', tr), ('va', va), ('te', test))}
        emb, _ = T.lookup(f'mask_no{fam}', df['dport'].values, df['proto'].values)
        Tt = {n: torch.tensor(emb[m]) for n, m in (('tr', tr), ('va', va), ('te', test))}
        fam_te = df['family'].values[test]; is_f = fam_te == fam; is_b = fam_te == 'Benign'
        de, dt = X['tr'].shape[1], emb.shape[1]; res[fam] = {'n_heldout_flows': int(is_f.sum()), 'n_benign_test': int(is_b.sum())}
        for name, mk in (('GraphAEGIS', lambda: M.GraphClassifier('aegis', de)), ('Hybrid', lambda: M.Hybrid(de, dt))):
            m = mk(); R.train_graph(m, G['tr'], y['tr'], Tt['tr'], G['va'], y['va'], Tt['va'], seed)
            p, z = R.predict_graph(m, G['te'], Tt['te'], seed, return_gate=True)
            r = {'detection_rate': float((p[is_f] >= 0.5).mean()), 'fpr_benign_fold1': float((p[is_b] >= 0.5).mean())}
            if z is not None: r['gate_heldout'] = float(z[is_f].mean()); r['gate_benign'] = float(z[is_b].mean())
            res[fam][name] = r; print(fam, name, r, flush=True)
            d = os.path.join(ROOT, 'predictions', 'logo', fam); os.makedirs(d, exist_ok=True)
            pd.DataFrame({'family': fam_te, 'y_true': y['te'], 'y_prob': p}).to_csv(os.path.join(d, f'{name}.csv'), index=False)
    json.dump(res, open(os.path.join(ROOT, 'logs', 'logo.json'), 'w'), indent=1)

if __name__ == '__main__':
    main()
