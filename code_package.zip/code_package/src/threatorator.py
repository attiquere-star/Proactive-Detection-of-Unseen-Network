# -*- coding: utf-8 -*-
"""Step 2. Threat-intelligence corpus, ThreatOrator (BERT with additive domain mask), retrieval index.

Corpus: CVE descriptions with CVE-ID year <= 2014 (the year in the identifier is used as the publication-period proxy,
because the source file has no publication date). Each document is assigned to one of the nine UNSW-NB15 families by
keyword matching (FAMILY_KEYWORDS, checked in the listed order; first match wins). Matched documents form the labelled
subset (fine-tuning, 9-class), the rest the unlabelled subset (masked-language-model pre-training).
Retrieval key: (destination port, transport protocol) extracted from the document text (explicit port numbers and the
service names in SERVICE_PORTS). Tie-break: when several documents share a key, the most recent document is used
(highest CVE year, then highest CVE sequence number). Fallbacks: same port with any protocol; then the most recent
document that names the flow's protocol; then the mean of all indexed embeddings.
"""
import os, re, json, math, argparse, random, time
import numpy as np, pandas as pd, torch
from transformers import BertForMaskedLM, BertForSequenceClassification, BertTokenizerFast

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, '..')
DATA = os.path.join(ROOT, 'data'); OUT = os.path.join(ROOT, 'text'); os.makedirs(OUT, exist_ok=True)
BERT = os.path.join(DATA, 'bert-mini')   # BERT-mini (4 layers, hidden 256; Turc et al. 2019), chosen for CPU-only compute
SEED = 42; LAMBDA = 1.5; MAXLEN = 96
FAMILIES = ['Fuzzers', 'Analysis', 'Backdoors', 'DoS', 'Exploits', 'Generic', 'Reconnaissance', 'Shellcode', 'Worms']
FAMILY_KEYWORDS = [
    ('Worms', ['worm']),
    ('Backdoors', ['backdoor', 'trojan', 'rootkit', 'hard-coded password', 'hardcoded password', 'hidden account', 'default password']),
    ('Shellcode', ['shellcode', 'shell code']),
    ('Analysis', ['cross-site scripting', 'xss', 'html injection', 'spam', 'port scan']),
    ('Reconnaissance', ['obtain sensitive information', 'information disclosure', 'enumerate', 'fingerprint', 'discover valid', 'scan']),
    ('Fuzzers', ['malformed', 'fuzz', 'long string', 'invalid packet', 'crafted packet']),
    ('DoS', ['denial of service']),
    ('Generic', ['cryptograph', 'cipher', 'hash collision', 'weak encryption', 'brute force', 'block cipher']),
    ('Exploits', ['execute arbitrary code', 'arbitrary command', 'buffer overflow', 'sql injection', 'gain privileges', 'command injection']),
]
SERVICE_PORTS = {'http': 80, 'https': 443, 'ftp': 21, 'ssh': 22, 'telnet': 23, 'smtp': 25, 'dns': 53, 'tftp': 69, 'pop3': 110,
                 'rpc': 111, 'portmapper': 111, 'ntp': 123, 'netbios': 139, 'imap': 143, 'snmp': 161, 'bgp': 179, 'ldap': 389,
                 'smb': 445, 'syslog': 514, 'rip': 520, 'mssql': 1433, 'pptp': 1723, 'nfs': 2049, 'mysql': 3306, 'rdp': 3389,
                 'sip': 5060, 'vnc': 5900, 'x11': 6000, 'irc': 6667, 'bittorrent': 6881}
UDP_SERVICES = {'dns', 'tftp', 'ntp', 'snmp', 'syslog', 'rip', 'sip'}
LEXICON = {'buffer', 'overflow', 'cve', 'sql', 'injection', 'exploit', 'denial', 'service', 'remote', 'attacker', 'attackers', 'arbitrary',
           'code', 'execute', 'execution', 'crafted', 'packet', 'packets', 'malformed', 'shellcode', 'backdoor', 'worm', 'trojan', 'rootkit',
           'privilege', 'privileges', 'vulnerability', 'xss', 'scripting', 'heap', 'stack', 'memory', 'corruption', 'authentication', 'bypass',
           'password', 'credentials', 'tcp', 'udp', 'icmp', 'port', 'http', 'ftp', 'ssh', 'smb', 'dns', 'smtp', 'telnet', 'snmp', 'rpc',
           'traversal', 'csrf', 'spoofing', 'scan', 'fuzz', 'cipher', 'cryptographic', 'hash', 'brute', 'malware', 'payload', 'command'}

def set_seed(s=SEED):
    random.seed(s); np.random.seed(s); torch.manual_seed(s)

# ------------------------------------------------------------------ corpus
def label_family(t):
    tl = t.lower()
    for fam, kws in FAMILY_KEYWORDS:
        if any(k in tl for k in kws): return fam
    return None

def keys_of(t):
    tl = t.lower(); ports = set()
    for m in re.finditer(r'\b(?:tcp|udp)?\s*ports?\s+(\d{1,5})\b', tl): ports.add(int(m.group(1)))
    for m in re.finditer(r'\b(?:tcp|udp)/(\d{1,5})\b', tl): ports.add(int(m.group(1)))
    for svc, p in SERVICE_PORTS.items():
        if re.search(r'\b' + re.escape(svc) + r'\b', tl): ports.add(p)
    ports = {p for p in ports if 0 < p < 65536}
    protos = set()
    if re.search(r'\budp\b', tl) or any(re.search(r'\b' + s + r'\b', tl) for s in UDP_SERVICES): protos.add('udp')
    if re.search(r'\btcp\b', tl) or (ports and 'udp' not in protos): protos.add('tcp')
    if re.search(r'\bicmp\b', tl): protos.add('icmp')
    return sorted(ports), sorted(protos)

def build_corpus():
    df = pd.read_csv(os.path.join(DATA, 'cve.csv'), usecols=['CVE-ID', 'DESCRIPTION'])
    df = df.dropna(); df['DESCRIPTION'] = df['DESCRIPTION'].astype(str)
    df = df[~df['DESCRIPTION'].str.contains(r'\*\* (?:REJECT|DISPUTED|RESERVED)', regex=True)]
    m = df['CVE-ID'].str.extract(r'CVE-(\d{4})-(\d+)')
    df['year'] = m[0].astype(int); df['seq'] = m[1].astype(int)
    df = df[df['year'] <= 2014].reset_index(drop=True)
    df['family'] = df['DESCRIPTION'].map(label_family)
    k = df['DESCRIPTION'].map(keys_of); df['ports'] = k.map(lambda x: x[0]); df['protos'] = k.map(lambda x: x[1])
    df.to_pickle(os.path.join(OUT, 'corpus.pkl'))
    stats = {'documents': int(len(df)), 'labelled': int(df['family'].notna().sum()), 'unlabelled': int(df['family'].isna().sum()),
             'labelled_per_family': {f: int((df['family'] == f).sum()) for f in FAMILIES},
             'documents_with_port_key': int((df['ports'].map(len) > 0).sum())}
    json.dump(stats, open(os.path.join(OUT, 'corpus_stats.json'), 'w'), indent=1); print(stats)
    return df

# ------------------------------------------------------------------ domain mask
def word_flags(tok, texts):
    enc = tok(texts, truncation=True, max_length=MAXLEN, padding='longest', return_tensors='pt', return_offsets_mapping=True)
    flags = torch.zeros_like(enc['input_ids'], dtype=torch.bool)
    for b, t in enumerate(texts):
        tl = t.lower(); spans = []
        for m in re.finditer(r"[a-z0-9][a-z0-9\-]*", tl):
            w = m.group(0)
            if w in LEXICON or re.fullmatch(r'cve-\d{4}-\d+', w): spans.append((m.start(), m.end()))
        if not spans: continue
        for i, (s, e) in enumerate(enc['offset_mapping'][b].tolist()):
            if e > s and any(s >= a and e <= z for a, z in spans): flags[b, i] = True
    enc.pop('offset_mapping')
    return enc, flags

def attn_bias(att_mask, flags, use_mask):
    B, L = att_mask.shape
    bias = torch.zeros(B, 1, L, L)
    if use_mask:
        pair = (flags[:, :, None] & flags[:, None, :]).float() * LAMBDA
        bias[:, 0] += pair
    bias = bias.masked_fill(att_mask[:, None, None, :] == 0, torch.finfo(torch.float32).min)
    return bias

# ------------------------------------------------------------------ training
def mlm_pretrain(df, use_mask, tag, max_docs=8000, bs=32, lr=1e-4):
    set_seed(); tok = BertTokenizerFast.from_pretrained(BERT)
    model = BertForMaskedLM.from_pretrained(BERT, attn_implementation='eager'); model.train()
    texts = df[df['family'].isna()]['DESCRIPTION'].tolist()
    rng = np.random.RandomState(SEED); rng.shuffle(texts); texts = texts[:max_docs]
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    t0 = time.time(); losses = []
    for i in range(0, len(texts), bs):
        enc, fl = word_flags(tok, texts[i:i + bs]); ids = enc['input_ids'].clone(); labels = ids.clone()
        special = (ids == tok.cls_token_id) | (ids == tok.sep_token_id) | (ids == tok.pad_token_id)
        prob = torch.full(ids.shape, 0.15); prob[special] = 0
        msk = torch.bernoulli(prob).bool(); labels[~msk] = -100
        rep = torch.bernoulli(torch.full(ids.shape, 0.8)).bool() & msk; ids[rep] = tok.mask_token_id
        rnd = torch.bernoulli(torch.full(ids.shape, 0.5)).bool() & msk & ~rep
        ids[rnd] = torch.randint(len(tok), ids.shape)[rnd]
        hid = model.bert(input_ids=ids, attention_mask=attn_bias(enc['attention_mask'], fl, use_mask)).last_hidden_state
        sel = labels != -100                                     # prediction head only at the masked positions
        loss = torch.nn.functional.cross_entropy(model.cls(hid[sel]), labels[sel])
        opt.zero_grad(); loss.backward(); opt.step(); losses.append(loss.item())
        if (i // bs) % 25 == 0: print(f'[mlm {tag}] {i}/{len(texts)} loss {np.mean(losses[-100:]):.3f} {time.time()-t0:.0f}s', flush=True)
    d = os.path.join(OUT, f'mlm_{tag}'); model.save_pretrained(d); tok.save_pretrained(d)
    return d, float(np.mean(losses[-100:]))

def finetune(df, mlm_dir, use_mask, tag, exclude=None, per_family=800, epochs=2, bs=32, lr=1e-4):
    set_seed(); tok = BertTokenizerFast.from_pretrained(mlm_dir)
    fams = [f for f in FAMILIES if f != exclude]
    lab = df[df['family'].isin(fams)]
    parts = []
    for f in fams:
        sub = lab[lab['family'] == f]
        parts.append(sub.sample(min(len(sub), per_family), random_state=SEED))
    lab = pd.concat(parts).sample(frac=1, random_state=SEED)
    y = torch.tensor(lab['family'].map({f: i for i, f in enumerate(fams)}).values)
    texts = lab['DESCRIPTION'].tolist()
    model = BertForSequenceClassification.from_pretrained(mlm_dir, num_labels=len(fams), attn_implementation='eager'); model.train()
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    n = len(texts); t0 = time.time()
    for ep in range(epochs):
        perm = np.random.RandomState(SEED + ep).permutation(n); correct = 0; tot = 0
        for i in range(0, n, bs):
            b = perm[i:i + bs]; enc, fl = word_flags(tok, [texts[j] for j in b])
            out = model(input_ids=enc['input_ids'], attention_mask=attn_bias(enc['attention_mask'], fl, use_mask), labels=y[b])
            opt.zero_grad(); out.loss.backward(); opt.step()
            correct += (out.logits.argmax(1) == y[b]).sum().item(); tot += len(b)
            if (i // bs) % 25 == 0: print(f'[ft {tag}] ep{ep} {i}/{n} acc {correct/max(tot,1):.3f} {time.time()-t0:.0f}s', flush=True)
    d = os.path.join(OUT, f'ft_{tag}'); model.save_pretrained(d); tok.save_pretrained(d)
    return d, {'n_finetune_docs': int(n), 'train_acc_last_epoch': correct / tot, 'families': fams}

@torch.no_grad()
def embed(model_dir, texts, use_mask, bs=64):
    tok = BertTokenizerFast.from_pretrained(model_dir)
    model = BertForSequenceClassification.from_pretrained(model_dir, attn_implementation='eager').eval()
    out = []
    for i in range(0, len(texts), bs):
        enc, fl = word_flags(tok, texts[i:i + bs])
        h = model.bert(input_ids=enc['input_ids'], attention_mask=attn_bias(enc['attention_mask'], fl, use_mask)).last_hidden_state[:, 0]
        out.append(h.numpy())
    return np.concatenate(out) if out else np.zeros((0, model.config.hidden_size), np.float32)

def build_index(df, model_dir, use_mask, tag, exclude=None):
    """Select one document per (port, proto) key with the tie-break rule, embed the selected documents."""
    d = df if exclude is None else df[df['family'] != exclude]
    d = d.sort_values(['year', 'seq'], ascending=False)          # most recent first -> first hit is the tie-break winner
    sel = {}
    for idx, ports, protos in zip(d.index, d['ports'], d['protos']):
        for p in ports:
            for pr in (protos or ['tcp']):
                sel.setdefault((p, pr), idx)
            sel.setdefault((p, '*'), idx)
        for pr in protos:
            sel.setdefault((-1, pr), idx)                       # protocol-level fallback
    docs = sorted(set(sel.values()))
    E = embed(model_dir, df.loc[docs, 'DESCRIPTION'].tolist(), use_mask)
    pos = {doc: i for i, doc in enumerate(docs)}
    keys = {f'{p}|{pr}': pos[i] for (p, pr), i in sel.items()}
    np.savez_compressed(os.path.join(OUT, f'index_{tag}.npz'), E=E, docs=np.array(docs))
    json.dump({'keys': keys, 'cve': {str(pos[i]): df.loc[i, 'CVE-ID'] for i in docs}}, open(os.path.join(OUT, f'index_{tag}.json'), 'w'))
    print(f'[index {tag}] {len(docs)} documents, {len(keys)} keys')
    return len(docs), len(keys)

def lookup(tag, dports, protos):
    z = np.load(os.path.join(OUT, f'index_{tag}.npz')); E = z['E']
    keys = json.load(open(os.path.join(OUT, f'index_{tag}.json')))['keys']
    mean = E.mean(0); out = np.zeros((len(dports), E.shape[1]), np.float32); src = np.zeros(len(dports), int)
    cache = {}
    for i, (p, pr) in enumerate(zip(dports, protos)):
        k = (int(p), pr)
        if k not in cache:
            for lvl, kk in enumerate((f'{p}|{pr}', f'{p}|*', f'-1|{pr}')):
                if kk in keys: cache[k] = (keys[kk], lvl); break
            else: cache[k] = (None, 3)
        j, lvl = cache[k]; out[i] = E[j] if j is not None else mean; src[i] = lvl
    return out, src

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--stage', default='all'); a = ap.parse_args()
    df = build_corpus() if not os.path.exists(os.path.join(OUT, 'corpus.pkl')) else pd.read_pickle(os.path.join(OUT, 'corpus.pkl'))
    log = {}
    for use_mask, mtag in ((True, 'mask'), (False, 'nomask')):
        if a.stage not in ('all', mtag): continue
        mdir, l = mlm_pretrain(df, use_mask, mtag); log[f'mlm_{mtag}_final_loss'] = l
        variants = [(None, mtag)] + ([('Worms', 'mask_noWorms'), ('Backdoors', 'mask_noBackdoors')] if use_mask else [])
        for exc, tag in variants:
            fdir, info = finetune(df, mdir, use_mask, tag, exclude=exc); log[f'ft_{tag}'] = info
            log[f'index_{tag}'] = build_index(df, fdir, use_mask, tag, exclude=exc)
        json.dump(log, open(os.path.join(OUT, f'train_log_{mtag}.json'), 'w'), indent=1)

if __name__ == '__main__':
    torch.set_num_threads(int(os.environ.get('NTHREADS', '4'))); main()
